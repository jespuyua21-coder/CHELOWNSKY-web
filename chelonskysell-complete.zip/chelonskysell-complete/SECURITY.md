# 🔒 Política de Seguridad

## Reportar una Vulnerabilidad

Si encuentras una vulnerabilidad de seguridad, **NO** la reportes públicamente en GitHub Issues.

En cambio, por favor:

1. **Envía un email privado** a: security@chelonsky.com
2. **Incluye**:
   - Descripción de la vulnerabilidad
   - Pasos para reproducirla
   - Impacto potencial
   - Sugerencias de fix (si tienes)

3. **Qué pasará**:
   - Reconocimiento dentro de 48 horas
   - Fix en tiempo récord
   - Publicación de patch
   - Agradecimiento público (si lo deseas)

## Prácticas de Seguridad

Este proyecto sigue estas prácticas:

### Dependencias
- ✅ Actualización regular de dependencias
- ✅ Revisión de seguridad con `npm audit`
- ✅ Uso de versiones stables

### Código
- ✅ TypeScript para type safety
- ✅ Sin `eval()` o código dinámico peligroso
- ✅ Validación de entrada
- ✅ Manejo de errores seguro

### Datos
- ✅ Sin servidor (datos en navegador del usuario)
- ✅ HTTPS recomendado en producción
- ✅ Cumple GDPR/privacidad
- ✅ No recolecta datos innecesarios

### Autenticación
- ✅ Contraseña SuperAdmin (configurable)
- ✅ Sesiones en localStorage
- ✅ Logout disponible

### PWA
- ✅ Manifiest.json validado
- ✅ HTTPS requerido en producción
- ✅ Service worker seguro

## Descargar de Forma Segura

1. **Verifica integridad**:
   ```bash
   git clone https://github.com/chelonsky/chelonskysell.git
   cd chelonskysell
   git verify-commit HEAD
   ```

2. **Instala dependencias seguramente**:
   ```bash
   npm ci  # En lugar de npm install
   npm audit
   ```

3. **Ejecuta en HTTPS** (producción)

## Requisitos de Seguridad para Contribuidores

Si contribuyes, asegúrate que:

- ✅ No introduces dependencias maliciosas
- ✅ Código sin vulnerabilidades conocidas
- ✅ Validación y sanitización de entrada
- ✅ Sin hardcoding de secretos
- ✅ Uso seguro de APIs

## Divulgación Responsable

Practicamos divulgación responsable:

1. Reporta privadamente
2. Damos tiempo para fix
3. Publicamos patch
4. Se divulga públicamente de forma segura

## Seguridad en Producción

Para usar CHELONSKYSELL en producción:

1. **Cambia contraseña SuperAdmin**:
   ```
   NEXT_PUBLIC_SUPER_ADMIN_PASSWORD=TuContraseña123
   ```

2. **Usa HTTPS**:
   - Obligatorio para PWA
   - Obligatorio para geolocalización
   - Recomendado para todo

3. **Backup regular**:
   - Descarga Excel cada semana
   - Guarda en lugar seguro
   - Considera Supabase/Drive para backups automáticos

4. **Actualiza dependencias**:
   ```bash
   npm update
   npm audit fix
   ```

5. **Monitorea logs** (si tienes servidor)

## Preguntas de Seguridad

¿Preguntas sobre seguridad?

- **Email**: security@chelonsky.com
- **Discusiones**: En privado
- **Issues**: SOLO si no es crítico

## Agradecimientos

Agradecemos a todos los que reportan vulnerabilidades responsablemente y ayudan a mejorar la seguridad de CHELONSKYSELL.

---

**Última actualización**: Enero 2024  
**Versión**: 1.0.0
