# 🏪 CHELONSKYSELL - Sistema de Gestión de Ventas y Créditos

Sistema profesional de gestión de ventas, créditos y clientes basado en **Excel como backend de datos**, sin necesidad de servidor en la nube. Diseñado específicamente para pequeños negocios con interfaz ultra simple y PWA (instalable como app en celular).

## ✨ Características Principales

### Para Business Owner (Dueño del Negocio)
- ✅ **Dashboard Intuitivo**: Deudores destacados y mejores clientes en grande
- 📦 **Crear Pedidos Ultra Rápido**: Menos de 30 segundos (cliente + descripción + monto)
- 📍 **Geolocalización Automática**: Captura ubicación GPS y genera link de Google Maps
- 💬 **Integración WhatsApp**: Envía pedidos completos a tu grupo de trabajo con un clic
- 💰 **Estados de Pago**: Pagado / Prestado / Abono Parcial
- 📊 **Exportar Excel Actualizado**: Descarga tu base de datos completa
- 🎯 **Gestión de Clientes**: Agrega clientes rápidamente sin formularios complejos

### Para SuperAdmin (Jesús - Dueño de CHELONSKYSELL)
- 🔐 **Panel Protegido**: Contraseña maestra para acceso administrativo
- 👥 **"Mis Clientes"**: Gestiona todos tus clientes que compraron la app
- 📅 **Fecha de Próximo Pago**: Recordatorios automáticos de suscripciones
- 💼 **Estados de Cliente**: Al día / Por vencer / Vencido
- ⚙️ **Wizard Automático**: Crea nuevo negocio y genera plantilla Excel automáticamente
- 📥 **Excel Maestro**: Descarga base de datos de clientes actualizada

## 🚀 Instalación Rápida

### Requisitos Previos
- **Node.js 18+** (descargar de [nodejs.org](https://nodejs.org))
- **npm** o **yarn** (viene incluido con Node.js)
- **Git** (opcional pero recomendado)

### Pasos de Instalación

1. **Clonar o descargar el proyecto**
```bash
git clone https://github.com/tuusuario/chelonskysell.git
cd chelonskysell
```

O si descargaste el ZIP, extrae y entra a la carpeta.

2. **Instalar dependencias**
```bash
npm install
```

Este paso puede tomar 1-2 minutos. Espera a que termine completamente.

3. **Configurar contraseña SuperAdmin (Opcional)**

Edita el archivo `.env.local` (créalo si no existe) en la raíz del proyecto:

```
NEXT_PUBLIC_SUPER_ADMIN_PASSWORD=CHELONSKY2024
```

Cambia "CHELONSKY2024" por tu contraseña preferida.

4. **Iniciar servidor de desarrollo**
```bash
npm run dev
```

La app se abrirá automáticamente en `http://localhost:3000`

Si no se abre, abre tu navegador y ve a esa dirección.

5. **Para producción (deployment)**
```bash
npm run build
npm start
```

## 💻 Cómo Usar

### Para Business Owner (Tú - Usuario de la App)

#### Primer Acceso
1. **Abre la app** (http://localhost:3000)
2. **Selecciona "MI NEGOCIO"**
3. **Carga tu Excel**: Arrastra tu archivo Excel o haz clic para seleccionar
   - El Excel debe tener hojas con: `Clientes` y `Pedidos`
   - Si no tienes uno, el SuperAdmin puede generar una plantilla

#### Dashboard Principal
Verás dos secciones destacadas:
- **Deudores 🔴**: Clientes que te deben dinero (ordenados por deuda mayor)
  - Botones rápidos: Llamar / Enviar WhatsApp
- **Mejores Clientes ⭐**: Tus mejores clientes por monto gastado

#### Crear Nuevo Pedido
1. Haz clic en el botón **"Nuevo Pedido 📦"** (muy grande en la página)
2. **Rellena rápidamente**:
   - Cliente (busca o agrega uno nuevo en 2 clics)
   - Descripción (qué se vendió)
   - Monto total
   - Estado de pago (Pagado / Prestado / Abono)
   - **📍 Botón GRANDE**: Usa tu ubicación GPS actual
     - Se rellena automáticamente con coordenadas
     - Genera link de Google Maps
3. Haz clic en **"Guardar Pedido"**
4. **Automáticamente se abre WhatsApp** con el pedido formateado
5. Copia el mensaje a tu grupo de trabajo/repartidores

#### Descargar Excel Actualizado
- Botón **"Descargar Excel Actualizado"** en el dashboard
- Guarda todos tus datos actuales en un archivo .xlsx
- Mantiene la estructura original del Excel
- Incluye todas las hojas: Dashboard, Clientes, Pedidos, Deudores, etc.

### Para SuperAdmin (Jesús)

#### Primer Acceso
1. Abre la app
2. Selecciona **"SUPERADMIN"**
3. Ingresa contraseña (por defecto: `CHELONSKY2024`)
4. Accede al panel de **"Mis Clientes"**

#### Agregar Nuevo Cliente
1. Haz clic en **"+ Agregar Cliente"** (botón verde grande)
2. Completa:
   - Nombre del negocio (ej: "La Tienda de Don Juan")
   - Giro (Vendedor, Licor, Ropa, Servicios, Boletaje, VIP, Otro)
   - Dueño (nombre)
   - WhatsApp (opcional)
   - Notas (opcional)
3. Haz clic en **"Crear Cliente y Plantilla"**
   - ✅ Se agrega a tu lista de clientes
   - ✅ **Automáticamente descarga un Excel plantilla** listo para el cliente
   - ✅ Se calcula fecha de próximo pago (30 días)

#### Gestionar Clientes
- **Tabla de clientes**: Ves todos tus clientes, estado de pago, próxima fecha
- **Botón "✓ Pagado"**: Marca como pagado y actualiza fecha de próximo pago
- **Botón "Eliminar"**: Quita el cliente de la lista
- **Botones de contacto**: Llamar / WhatsApp directo al cliente

#### Descargar Excel Maestro
- **Botón "Descargar Excel"** (azul) en la parte superior
- Genera un Excel con todos tus clientes
- Usa para registros y análisis

## 📊 Estructura de Datos (Excel)

El Excel que cargues o que se genere debe tener estas hojas:

### Hoja "Dashboard"
Resumen con fórmulas (se genera automáticamente)
```
| Métrica | Valor |
| Total de Clientes | 15 |
| Total de Pedidos | 45 |
| Deuda Total | $5,230.00 |
```

### Hoja "Clientes"
```
| id | nombre | telefono | deuda | totalGastado |
| 1 | Juan Pérez | +52 1234567890 | 0 | 5000 |
| 2 | María García | +52 9876543210 | 1500 | 3200 |
```

### Hoja "Pedidos"
```
| id | numero | clienteId | clienteNombre | descripcion | monto | estado | latitud | longitud | direccion | fechaCreacion |
| 1 | PED-001 | 1 | Juan Pérez | 2x Cerveza | 200 | pagado | 19.4326 | -99.1332 | ... | 2024-01-15 |
```

### Hoja "Deudores"
Se genera automáticamente desde los pedidos con estado "prestado" o "abono_parcial"

### Hoja "Config"
```
| propiedad | valor |
| colorPrimario | #22c55e |
| monedaPais | MXN |
| codigoPais | +52 |
```

## 🎨 Interfaz y Diseño

- **Tema Oscuro Premium**: Fondo negro con acentos en neon green (#22c55e)
- **Botones Grandes**: Especialmente diseñados para uso en mobile
- **Responsive**: Se adapta a teléfono, tablet y escritorio
- **100% en Español**: Interfaz, mensajes y documentación en español neutro

## 📱 PWA - Instalar como App

CHELONSKYSELL es una PWA (Progressive Web App), se puede instalar en tu celular:

### En iPhone
1. Abre Safari
2. Ve a tu URL (ej: https://tudominio.com)
3. Toca el botón de compartir (cuadrado con flecha)
4. Selecciona "Agregar a pantalla de inicio"
5. Elige nombre y confirma

### En Android
1. Abre Chrome
2. Ve a tu URL
3. Toca los 3 puntos (menú) arriba a la derecha
4. Selecciona "Instalar aplicación" o "Agregar a pantalla de inicio"
5. Confirma

La app funcionará offline con los datos que tengas cargados.

## 🔄 Flujo de Trabajo Recomendado

### Para Vendedor Pequeño
```
1. Mañana: Carga tu Excel con clientes y pedidos
2. Día: Crea pedidos rápidamente (30 segundos cada uno)
3. Envía cada pedido a WhatsApp grupo con ubicación GPS
4. Registra si fue pagado o prestado
5. Semana: Descarga Excel actualizado para backup
```

### Para SuperAdmin
```
1. Cada cliente nuevo: Agregar en "Mis Clientes"
   → Se genera automáticamente Excel plantilla
2. Recordar pagos: Ver columna "Próx. Pago" en la tabla
3. Mensual: Descargar Excel maestro de clientes
4. Seguimiento: WhatsApp a clientes próximos a vencer
```

## ⚙️ Configuración Avanzada

### Cambiar Colores de Tema
Edita `tailwind.config.js`:
```javascript
'chelonsky': {
  400: '#4ade80', // Color principal (neon green)
  // Cambiar a otro color si deseas
}
```

### Cambiar Contraseña SuperAdmin
Opción 1: Variable de entorno
```
NEXT_PUBLIC_SUPER_ADMIN_PASSWORD=TuContraseña123
```

Opción 2: En el código (menos seguro)
Edita `lib/stores/authStore.ts` línea con `SUPER_ADMIN_PASSWORD`

### Extender Funcionalidades

#### Agregar más estados de pedido
Edita `lib/stores/businessStore.ts`, tipo `Pedido`:
```typescript
estado: 'pagado' | 'prestado' | 'abono_parcial' | 'cancelado'; // Agregar 'cancelado'
```

#### Agregar campos al cliente
Edita `lib/stores/businessStore.ts`, tipo `Cliente`:
```typescript
interface Cliente {
  id: string;
  nombre: string;
  telefono: string;
  email?: string; // Nuevo campo
  deuda?: number;
  totalGastado?: number;
}
```

#### Agregar más giros de negocio
Edita `app/superadmin/mis-clientes/page.tsx`:
```typescript
const girosDisponibles = [
  'Vendedor',
  'Licor',
  'Ropa',
  'Servicios',
  'Boletaje',
  'VIP',
  'Farmacia', // Nuevo
  'Otro',
];
```

## 🚀 Deployment (Publicar en Internet)

### Opción 1: Vercel (Recomendado - Gratis)
1. Ve a [vercel.com](https://vercel.com)
2. Crea cuenta (con GitHub/Google)
3. Haz clic "New Project"
4. Importa tu repositorio de GitHub
5. Click "Deploy"
6. ¡Listo! Tu app estará en `https://tuproyecto.vercel.app`

### Opción 2: Netlify
1. Ve a [netlify.com](https://netlify.com)
2. Crea cuenta
3. Drag & drop tu carpeta compilada, o conecta GitHub
4. Configura: Build command = `npm run build`, Publish = `.next`
5. ¡Listo!

### Opción 3: Tu propio servidor
```bash
npm run build
npm start
```
Deploy la carpeta a tu servidor (ej: DigitalOcean, Linode, etc.)

## 🐛 Troubleshooting

### "Error: Port 3000 is already in use"
```bash
npm run dev -- -p 3001
# O cambia el puerto en otro terminal
```

### "Excel no carga correctamente"
- Asegúrate que el Excel tiene las hojas: `Clientes` y `Pedidos`
- Los nombres de las hojas deben coincidir exactamente (con mayúsculas)
- Guarda el Excel en formato .xlsx (no .xls antiguo)

### "Geolocalización no funciona en dev"
- En localhost, a veces pide permisos múltiples
- Usa incógnito para resetear permisos
- En producción funciona mejor

### "WhatsApp no se abre"
- Verifica que tengas WhatsApp Web o app instalada
- Algunos navegadores bloquean popups - habilita para este sitio

### "Los datos se pierden al refrescar"
- Por ahora usa localStorage (se pierden si limpias cache)
- Próxima versión: Sincronización con Supabase opcional

## 📝 Notas Técnicas

### Stack Usado
- **Frontend**: Next.js 14 + React 18 + TypeScript
- **Estilos**: Tailwind CSS
- **Estado**: Zustand
- **Excel**: SheetJS (xlsx)
- **Geolocalización**: Navigator Geolocation API (nativa)
- **PWA**: next-pwa
- **Despliegue**: Vercel, Netlify, o servidor propio

### Almacenamiento de Datos
- **Actualmente**: localStorage del navegador
- **Seguridad**: No se envía a servidores, todo local
- **Backup**: Descarga Excel regularmente

### Performance
- Interfaz muy rápida (carga en <1 segundo)
- Funciona offline una vez cargada
- Optimizado para mobile (350KB gzipped)

## 📞 Soporte

Si tienes preguntas o problemas:
1. Revisa esta documentación
2. Abre una issue en GitHub
3. Contacta a Jesús (owner de CHELONSKYSELL)

## 📄 Licencia

CHELONSKYSELL © 2024 Chelonsky Store. Todos los derechos reservados.

---

## 🎯 Roadmap (Próximas Mejoras)

- [ ] Sincronización con Google Sheets (alternativa a Excel)
- [ ] Backup automático a Drive/Dropbox
- [ ] Editor de tickets con generación de imagen PNG
- [ ] Gráficos de ventas por día/mes
- [ ] Notificaciones push para deudores próximos a vencer
- [ ] Múltiples usuarios por negocio (repartidores)
- [ ] Facturación automática (opcional)
- [ ] App nativa para iOS/Android
- [ ] Integración con PayPal/Stripe (pagos online)

---

**Versión**: 1.0.0  
**Última actualización**: Enero 2024  
**Creado con ❤️ por Chelonsky Store**

¡Gracias por usar CHELONSKYSELL! 🎉
