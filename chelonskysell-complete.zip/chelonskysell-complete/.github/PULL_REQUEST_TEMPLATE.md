## Descripción
Describe los cambios que hiciste en este PR.

## Tipo de Cambio
- [ ] 🐛 Bug fix (cambio que arregla un problema)
- [ ] ✨ Nueva característica (cambio que agrega funcionalidad)
- [ ] 📚 Documentación
- [ ] 🎨 Estilos/UI
- [ ] ♻️ Refactor
- [ ] ⚡ Performance
- [ ] 🔐 Seguridad

## ¿Cómo fue probado?
Describe cómo probaste los cambios.

## Checklist
- [ ] Mi código sigue los estilos del proyecto
- [ ] He actualizado la documentación
- [ ] Mis cambios generan nuevas advertencias
- [ ] He agregado tests (si aplica)
- [ ] Los cambios funcionan localmente

## Screenshots (si aplica)
Si hay cambios visuales, agrega capturas.

## Issues Relacionados
Cierra: #(número del issue si aplica)

## Notas Adicionales
Información extra relevante.
