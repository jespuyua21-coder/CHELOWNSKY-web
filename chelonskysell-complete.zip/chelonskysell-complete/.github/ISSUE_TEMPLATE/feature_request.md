---
name: ✨ Solicitud de Característica
about: Sugiere una nueva feature o mejora
title: "[FEATURE] "
labels: enhancement
assignees: ''

---

## Descripción
Describe claramente la nueva característica que solicitas.

## Problema que Resuelve
¿Qué problema resuelve esta característica?

## Solución Propuesta
Describe cómo te gustaría que funcione.

## Alternativas Consideradas
¿Hay otras formas de resolver esto?

## Contexto Adicional
Información extra que sea relevante.

## Prioridad
- [ ] Baja
- [ ] Media
- [ ] Alta
- [ ] Crítica
