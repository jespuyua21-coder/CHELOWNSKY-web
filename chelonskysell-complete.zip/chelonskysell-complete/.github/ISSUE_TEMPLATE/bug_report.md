---
name: 🐛 Reporte de Bug
about: Reporta un error en la aplicación
title: "[BUG] "
labels: bug
assignees: ''

---

## Descripción del Bug
Describe claramente qué no funciona.

## Pasos para Reproducir
1. Paso 1...
2. Paso 2...
3. Paso 3...

## Comportamiento Esperado
¿Qué debería pasar?

## Comportamiento Actual
¿Qué está pasando en realidad?

## Capturas de Pantalla
Si aplica, agrega capturas.

## Entorno
- SO: [Windows / Mac / Linux]
- Navegador: [Chrome / Safari / Firefox / Edge]
- Versión: [1.0.0]
- Node.js: [versión]

## Notas Adicionales
Información relevante extra.
