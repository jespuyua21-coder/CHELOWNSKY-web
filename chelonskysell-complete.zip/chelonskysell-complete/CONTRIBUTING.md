# 🤝 Guía de Contribución - CHELONSKYSELL

¡Gracias por interesarte en contribuir a CHELONSKYSELL! Este documento te guía sobre cómo hacerlo.

## 📋 Código de Conducta

Este proyecto tiene un código de conducta. Al participar, aceptas respetarlo. Sé respetuoso, inclusivo y constructivo.

## 🐛 ¿Encontraste un Bug?

1. **Verifica** que el bug no está ya reportado en [Issues](https://github.com/chelonsky/chelonskysell/issues)
2. **Crea un nuevo issue** usando el template de bug report
3. **Describe claramente**:
   - Qué esperabas que pasara
   - Qué está pasando en realidad
   - Pasos para reproducir
   - Tu entorno (SO, navegador, Node.js)

## ✨ ¿Tienes una Idea de Mejora?

1. **Verifica** que no exista ya en [Issues](https://github.com/chelonsky/chelonskysell/issues)
2. **Abre un issue** con el template de feature request
3. **Explica claramente**:
   - Qué problema resuelve
   - Cómo debería funcionar
   - Alternativas consideradas
   - Prioridad aproximada

## 📝 ¿Quieres Hacer un Pull Request?

### Prerequisitos
- Node.js 18+
- npm o yarn
- Git

### Pasos

1. **Fork el repositorio**
   ```bash
   git clone https://github.com/TU_USUARIO/chelonskysell.git
   cd chelonskysell
   ```

2. **Crea una rama para tu feature**
   ```bash
   git checkout -b feature/mi-feature
   # O para bugfix
   git checkout -b fix/mi-bug
   ```

3. **Instala dependencias**
   ```bash
   npm install
   ```

4. **Haz cambios y prueba**
   ```bash
   npm run dev
   # Prueba localmente en http://localhost:3000
   ```

5. **Commit con mensajes claros**
   ```bash
   git commit -m "feat: agregar nueva funcionalidad"
   # O para bugs:
   git commit -m "fix: arreglar error en pedidos"
   ```

   **Formato de commits recomendado:**
   - `feat:` para nuevas características
   - `fix:` para bug fixes
   - `docs:` para documentación
   - `style:` para estilos (CSS, formato)
   - `refactor:` para refactorización
   - `perf:` para mejoras de performance
   - `test:` para tests

6. **Push a tu fork**
   ```bash
   git push origin feature/mi-feature
   ```

7. **Abre un Pull Request**
   - Usa el template de PR
   - Describe qué cambios hiciste y por qué
   - Enlaza el issue relacionado (si existe)
   - Verifica que pasen los checks de CI

## 🎨 Guías de Estilo

### TypeScript
- Usa tipos explícitos
- Evita `any`
- Comenta código complejo

### React
- Componentes funcionales
- Hooks modernos
- Props bien tipadas

### CSS/Tailwind
- Usa clases Tailwind existentes
- Evita CSS custom si no es necesario
- Mantén consistencia de colores

### Documentación
- Comenta funciones complejas
- Usa JSDoc para funciones públicas
- Mantén README.md actualizado

## ✅ Checklist Antes de Hacer PR

- [ ] Código sigue estilos del proyecto
- [ ] Documentación actualizada
- [ ] Sin `console.log()` de debug
- [ ] TypeScript sin errores (`npm run build`)
- [ ] Probado localmente
- [ ] Commits con mensajes claros
- [ ] No introduce nuevas dependencias sin discusión

## 📚 Estructura del Proyecto

```
chelonskysell/
├── app/              # Rutas y páginas
├── components/       # Componentes React
├── lib/
│   ├── stores/       # Estado (Zustand)
│   └── utils/        # Utilidades
├── public/           # Assets estáticos
├── .github/          # GitHub templates y workflows
├── docs/             # Documentación adicional
└── README.md         # Documentación principal
```

## 🔄 Proceso de Review

1. Un mantenedor revisará tu PR
2. Puede solicitar cambios
3. Una vez aprobado, se mergea a `develop`
4. Luego se hace release a `main`

## 📦 Proceso de Release

- Versiones semantics: `MAJOR.MINOR.PATCH`
- Cambios en `develop` se taguean y releasan
- Se actualiza CHANGELOG.md
- Se publican notas de release

## 🚀 Después de tu PR

Una vez mergueado:
- ¡Eres un contribuidor! 🎉
- Tu nombre aparece en CONTRIBUTORS.md
- Se agradece en el release correspondiente

## ❓ Preguntas

- Discusiones: [GitHub Discussions](https://github.com/chelonsky/chelonskysell/discussions)
- Issues: Para bugs y features
- Contacto: El dueño del proyecto

## 📖 Recursos

- [Next.js Docs](https://nextjs.org/docs)
- [React Docs](https://react.dev)
- [TypeScript Docs](https://www.typescriptlang.org/docs)
- [Tailwind Docs](https://tailwindcss.com/docs)

---

**¡Gracias por contribuir a CHELONSKYSELL! Cada aporte ayuda a mejorar la app para todos.** 🙌
