'use client';

import { useAuthStore } from '@/lib/stores/authStore';
import { useRouter } from 'next/navigation';
import { Header } from '@/components/Header';
import { useEffect } from 'react';

export default function BusinessLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const { isAuthenticated, isSuperAdmin } = useAuthStore();
  const router = useRouter();

  useEffect(() => {
    if (!isAuthenticated) {
      router.push('/');
    } else if (isSuperAdmin) {
      router.push('/superadmin/mis-clientes');
    }
  }, [isAuthenticated, isSuperAdmin, router]);

  if (!isAuthenticated || isSuperAdmin) {
    return null;
  }

  return (
    <>
      <Header />
      <main className="min-h-screen bg-premium-dark">
        {children}
      </main>
    </>
  );
}
