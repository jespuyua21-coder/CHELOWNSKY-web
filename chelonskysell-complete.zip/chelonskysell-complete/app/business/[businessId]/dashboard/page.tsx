'use client';

import { useBusinessStore } from '@/lib/stores/businessStore';
import { useAuthStore } from '@/lib/stores/authStore';
import { useRouter, useParams } from 'next/navigation';
import { useEffect, useState } from 'react';
import { generateExcelFile } from '@/lib/excelUtils';
import { generateWhatsAppLink, formatMoney } from '@/lib/whatsappUtils';
import {
  Download,
  Plus,
  Phone,
  AlertCircle,
  TrendingUp,
  MessageCircle,
} from 'lucide-react';

export default function BusinessDashboard() {
  const params = useParams();
  const businessId = params.businessId as string;
  const router = useRouter();
  const { currentBusinessId } = useAuthStore();
  const { businesses } = useBusinessStore();
  const [business, setBusiness] = useState<any>(null);

  useEffect(() => {
    const b = businesses.find((b) => b.id === businessId);
    if (!b) {
      router.push('/business');
    } else {
      setBusiness(b);
    }
  }, [businessId, businesses, router]);

  if (!business) {
    return <div className="flex items-center justify-center min-h-screen">Cargando...</div>;
  }

  // Calcular deudores (clientes que deben dinero)
  const deudoresArray = Object.entries(business.deudores)
    .filter(([_, monto]: [string, any]) => monto > 0)
    .map(([clienteId, monto]: [string, any]) => {
      const cliente = business.clientes.find((c: any) => c.id === clienteId);
      return {
        clienteId,
        nombre: cliente?.nombre || 'Desconocido',
        telefono: cliente?.telefono || '',
        deuda: monto,
      };
    })
    .sort((a, b) => b.deuda - a.deuda);

  // Calcular mejores clientes (top por monto gastado)
  const mejoresClientes = [...business.clientes]
    .sort((a, b) => (b.totalGastado || 0) - (a.totalGastado || 0))
    .slice(0, 5);

  // Totales
  const totalDeuda = Object.values(business.deudores).reduce((a: number, b: any) => a + b, 0);
  const totalPedidos = business.pedidos.length;
  const totalClientes = business.clientes.length;

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      {/* Sección de acciones rápidas */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
        <button
          onClick={() => router.push(`/business/${businessId}/pedidos`)}
          className="btn-primary-lg flex items-center justify-center gap-3"
        >
          <Plus className="w-6 h-6" />
          Nuevo Pedido
        </button>

        <button
          onClick={() => generateExcelFile(business)}
          className="btn-primary-lg flex items-center justify-center gap-3"
        >
          <Download className="w-6 h-6" />
          Descargar Excel Actualizado
        </button>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="card">
          <p className="text-gray-400 text-sm mb-2">Total de Clientes</p>
          <p className="text-4xl font-bold text-chelonsky-400">{totalClientes}</p>
        </div>
        <div className="card">
          <p className="text-gray-400 text-sm mb-2">Pedidos Registrados</p>
          <p className="text-4xl font-bold text-chelonsky-400">{totalPedidos}</p>
        </div>
        <div className="card border-red-600/30">
          <p className="text-gray-400 text-sm mb-2">Deuda Total</p>
          <p className="text-4xl font-bold text-red-500">{formatMoney(totalDeuda)}</p>
        </div>
      </div>

      {/* Sección de Deudores */}
      <div className="mb-8">
        <h2 className="text-3xl font-bold mb-4 flex items-center gap-2">
          <AlertCircle className="w-8 h-8 text-red-500" />
          Deudores 🔴
        </h2>

        {deudoresArray.length === 0 ? (
          <div className="card text-center py-12">
            <p className="text-gray-400 text-lg">¡Excelente! No hay deudores actualmente</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {deudoresArray.map((deudor) => (
              <div key={deudor.clienteId} className="card border-red-600/30 hover:border-red-600/50">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h3 className="font-bold text-lg">{deudor.nombre}</h3>
                    <p className="text-sm text-gray-400">{deudor.telefono}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-xl font-bold text-red-500">
                      {formatMoney(deudor.deuda)}
                    </p>
                  </div>
                </div>

                <div className="flex gap-2">
                  <a
                    href={`tel:${deudor.telefono}`}
                    className="flex-1 flex items-center justify-center gap-2 px-3 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg transition-all"
                  >
                    <Phone className="w-4 h-4" />
                    <span className="text-sm">Llamar</span>
                  </a>
                  <a
                    href={generateWhatsAppLink(
                      {
                        id: deudor.clienteId,
                        numero: '',
                        clienteId: deudor.clienteId,
                        clienteNombre: deudor.nombre,
                        clienteTelefono: deudor.telefono,
                        descripcion: `Deuda pendiente: ${formatMoney(deudor.deuda)}`,
                        monto: deudor.deuda,
                        estado: 'prestado',
                        fechaCreacion: new Date().toISOString(),
                      },
                      true
                    )}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 flex items-center justify-center gap-2 px-3 py-2 bg-green-600 hover:bg-green-700 rounded-lg transition-all"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span className="text-sm">WhatsApp</span>
                  </a>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Sección de Mejores Clientes */}
      <div>
        <h2 className="text-3xl font-bold mb-4 flex items-center gap-2">
          <TrendingUp className="w-8 h-8 text-chelonsky-400" />
          Mejores Clientes ⭐
        </h2>

        {mejoresClientes.length === 0 ? (
          <div className="card text-center py-12">
            <p className="text-gray-400 text-lg">Aún no tienes clientes registrados</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {mejoresClientes.map((cliente) => (
              <div
                key={cliente.id}
                className="card border-chelonsky-400/30 hover:border-chelonsky-400/50"
              >
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h3 className="font-bold text-lg">{cliente.nombre}</h3>
                    <p className="text-sm text-gray-400">{cliente.telefono}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-xl font-bold text-chelonsky-400">
                      {formatMoney(cliente.totalGastado || 0)}
                    </p>
                    <p className="text-xs text-gray-400">Total gastado</p>
                  </div>
                </div>

                <button
                  onClick={() => router.push(`/business/${businessId}/clientes/${cliente.id}`)}
                  className="w-full px-4 py-2 bg-chelonsky-400/20 hover:bg-chelonsky-400/40 text-chelonsky-400 rounded-lg transition-all"
                >
                  Ver Detalles
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
