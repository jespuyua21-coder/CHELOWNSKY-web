'use client';

import { useState, useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { useBusinessStore, Pedido } from '@/lib/stores/businessStore';
import { getCurrentLocation, generateGoogleMapsLink } from '@/lib/geolocationUtils';
import { generateWhatsAppLink } from '@/lib/whatsappUtils';
import { Modal } from '@/components/Modal';
import {
  MapPin,
  Plus,
  Send,
  Loader2,
  MessageCircle,
} from 'lucide-react';

export default function NuevoPedidoPage() {
  const params = useParams();
  const businessId = params.businessId as string;
  const router = useRouter();
  const { businesses, addPedido, addCliente } = useBusinessStore();
  const [business, setBusiness] = useState<any>(null);

  // Formulario
  const [clienteId, setClienteId] = useState('');
  const [nuevoCliente, setNuevoCliente] = useState('');
  const [nuevoClienteTelefono, setNuevoClienteTelefono] = useState('');
  const [descripcion, setDescripcion] = useState('');
  const [monto, setMonto] = useState('');
  const [estado, setEstado] = useState<'pagado' | 'prestado' | 'abono_parcial'>('pagado');
  const [montoAbono, setMontoAbono] = useState('');
  const [notas, setNotas] = useState('');
  const [geolocalizando, setGeolocalizando] = useState(false);
  const [ubicacion, setUbicacion] = useState<{
    latitud: number;
    longitud: number;
    direccion: string;
    linkMaps: string;
  } | null>(null);
  const [direccionManual, setDireccionManual] = useState('');
  const [newClientModalOpen, setNewClientModalOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    const b = businesses.find((b) => b.id === businessId);
    if (b) {
      setBusiness(b);
    }
  }, [businessId, businesses]);

  const handleGeolocalizar = async () => {
    setGeolocalizando(true);
    try {
      const coords = await getCurrentLocation();
      const linkMaps = generateGoogleMapsLink(coords.latitud, coords.longitud);
      setUbicacion({
        latitud: coords.latitud,
        longitud: coords.longitud,
        direccion: `Ubicación GPS: ${coords.latitud.toFixed(6)}, ${coords.longitud.toFixed(6)}`,
        linkMaps,
      });
      setDireccionManual('');
    } catch (err) {
      setError(`Error: ${err instanceof Error ? err.message : 'Desconocido'}`);
    } finally {
      setGeolocalizando(false);
    }
  };

  const handleAgregarCliente = () => {
    if (!nuevoCliente.trim() || !nuevoClienteTelefono.trim()) {
      setError('Por favor completa nombre y teléfono');
      return;
    }

    const id = Math.random().toString(36).substr(2, 9);
    addCliente(businessId, {
      id,
      nombre: nuevoCliente,
      telefono: nuevoClienteTelefono,
    });

    setClienteId(id);
    setNuevoCliente('');
    setNuevoClienteTelefono('');
    setNewClientModalOpen(false);
  };

  const handleGuardarPedido = async () => {
    if (!clienteId.trim() || !descripcion.trim() || !monto.trim()) {
      setError('Por favor completa: cliente, descripción y monto');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const cliente = business.clientes.find((c: any) => c.id === clienteId);
      const numeroSiguiente = (business.pedidos.length + 1).toString().padStart(3, '0');

      // Crear ubicación si ingresó dirección manual
      let finalUbicacion = ubicacion;
      if (direccionManual && !finalUbicacion) {
        // Generar coordenadas ficticias basadas en la dirección
        finalUbicacion = {
          latitud: 0,
          longitud: 0,
          direccion: direccionManual,
          linkMaps: '#',
        };
      }

      const pedido: Pedido = {
        id: Math.random().toString(36).substr(2, 9),
        numero: `PED-${numeroSiguiente}`,
        clienteId,
        clienteNombre: cliente.nombre,
        clienteTelefono: cliente.telefono,
        descripcion,
        monto: parseFloat(monto),
        estado,
        montoAbono: estado === 'abono_parcial' ? parseFloat(montoAbono) : undefined,
        ubicacion: finalUbicacion || undefined,
        fechaCreacion: new Date().toISOString(),
        notas,
      };

      addPedido(businessId, pedido);

      // Limpiar formulario
      setClienteId('');
      setDescripcion('');
      setMonto('');
      setEstado('pagado');
      setMontoAbono('');
      setNotas('');
      setUbicacion(null);
      setDireccionManual('');

      // Mostrar modal para enviar por WhatsApp
      handleEnviarWhatsApp(pedido);
    } catch (err) {
      setError(`Error al guardar: ${err instanceof Error ? err.message : 'Desconocido'}`);
    } finally {
      setLoading(false);
    }
  };

  const handleEnviarWhatsApp = (pedido: Pedido) => {
    const link = generateWhatsAppLink(pedido, true);
    window.open(link, '_blank');
  };

  if (!business) {
    return <div className="flex items-center justify-center min-h-screen">Cargando...</div>;
  }

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      <button
        onClick={() => router.back()}
        className="mb-6 text-gray-400 hover:text-white transition-colors"
      >
        ← Volver
      </button>

      <h1 className="text-4xl font-bold mb-8">
        Nuevo Pedido <span className="text-chelonsky-400">📦</span>
      </h1>

      {error && (
        <div className="mb-6 p-4 bg-red-900/20 border border-red-600 rounded-lg text-red-400">
          {error}
        </div>
      )}

      <div className="space-y-6">
        {/* Cliente */}
        <div className="card">
          <label className="block text-sm font-medium text-gray-300 mb-2">Cliente *</label>
          <div className="flex gap-2">
            <select
              value={clienteId}
              onChange={(e) => setClienteId(e.target.value)}
              className="flex-1 px-4 py-2 bg-dark-bg border border-dark-border rounded-lg input-focus text-white"
            >
              <option value="">-- Selecciona un cliente --</option>
              {business.clientes.map((c: any) => (
                <option key={c.id} value={c.id}>
                  {c.nombre} ({c.telefono})
                </option>
              ))}
            </select>
            <button
              onClick={() => setNewClientModalOpen(true)}
              className="px-4 py-2 bg-chelonsky-400/20 hover:bg-chelonsky-400/40 text-chelonsky-400 rounded-lg transition-all flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              Nuevo
            </button>
          </div>
        </div>

        {/* Ubicación y Geolocalización */}
        <div className="card">
          <label className="block text-sm font-medium text-gray-300 mb-2">
            Ubicación / Dirección
          </label>
          <button
            onClick={handleGeolocalizar}
            disabled={geolocalizando}
            className="w-full mb-4 flex items-center justify-center gap-2 px-4 py-3 bg-chelonsky-400 hover:bg-chelonsky-500 disabled:bg-gray-600 text-black font-bold rounded-lg transition-all"
          >
            {geolocalizando ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Obteniendo ubicación...
              </>
            ) : (
              <>
                <MapPin className="w-5 h-5" />
                📍 Usar mi ubicación actual
              </>
            )}
          </button>

          {ubicacion && (
            <div className="mb-4 p-3 bg-dark-bg rounded-lg border border-chelonsky-400/30">
              <p className="text-sm text-gray-300 mb-1">{ubicacion.direccion}</p>
              <a
                href={ubicacion.linkMaps}
                target="_blank"
                rel="noopener noreferrer"
                className="text-sm text-chelonsky-400 hover:underline"
              >
                Ver en mapa →
              </a>
            </div>
          )}

          <label className="block text-sm text-gray-400 mb-2">O ingresa dirección manual:</label>
          <input
            type="text"
            value={direccionManual}
            onChange={(e) => setDireccionManual(e.target.value)}
            placeholder="Ej: Calle 5 de Mayo #123, Apartado 4B"
            className="w-full px-4 py-2 bg-dark-bg border border-dark-border rounded-lg input-focus text-white placeholder-gray-500"
          />
        </div>

        {/* Descripción */}
        <div className="card">
          <label className="block text-sm font-medium text-gray-300 mb-2">Descripción *</label>
          <textarea
            value={descripcion}
            onChange={(e) => setDescripcion(e.target.value)}
            placeholder="Ej: 2x Cerveza Corona, 1x Refresco"
            rows={3}
            className="w-full px-4 py-2 bg-dark-bg border border-dark-border rounded-lg input-focus text-white placeholder-gray-500"
          />
        </div>

        {/* Monto */}
        <div className="card">
          <label className="block text-sm font-medium text-gray-300 mb-2">Monto Total *</label>
          <div className="flex items-center gap-2">
            <span className="text-xl font-bold text-gray-400">$</span>
            <input
              type="number"
              step="0.01"
              value={monto}
              onChange={(e) => setMonto(e.target.value)}
              placeholder="0.00"
              className="flex-1 px-4 py-2 bg-dark-bg border border-dark-border rounded-lg input-focus text-white placeholder-gray-500 text-xl"
            />
          </div>
        </div>

        {/* Estado de Pago */}
        <div className="card">
          <label className="block text-sm font-medium text-gray-300 mb-2">Estado de Pago *</label>
          <div className="space-y-3">
            <button
              onClick={() => setEstado('pagado')}
              className={`w-full px-4 py-3 rounded-lg font-bold transition-all ${
                estado === 'pagado'
                  ? 'bg-green-600 text-white'
                  : 'bg-dark-bg border border-dark-border text-gray-300 hover:border-green-600'
              }`}
            >
              ✅ Pagado
            </button>
            <button
              onClick={() => setEstado('prestado')}
              className={`w-full px-4 py-3 rounded-lg font-bold transition-all ${
                estado === 'prestado'
                  ? 'bg-red-600 text-white'
                  : 'bg-dark-bg border border-dark-border text-gray-300 hover:border-red-600'
              }`}
            >
              🔴 Prestado (Sin pagar)
            </button>
            <button
              onClick={() => setEstado('abono_parcial')}
              className={`w-full px-4 py-3 rounded-lg font-bold transition-all ${
                estado === 'abono_parcial'
                  ? 'bg-yellow-600 text-white'
                  : 'bg-dark-bg border border-dark-border text-gray-300 hover:border-yellow-600'
              }`}
            >
              ⏳ Abono Parcial
            </button>
          </div>

          {estado === 'abono_parcial' && (
            <div className="mt-4">
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Monto del Abono
              </label>
              <div className="flex items-center gap-2">
                <span className="text-xl font-bold text-gray-400">$</span>
                <input
                  type="number"
                  step="0.01"
                  value={montoAbono}
                  onChange={(e) => setMontoAbono(e.target.value)}
                  placeholder="0.00"
                  className="flex-1 px-4 py-2 bg-dark-bg border border-dark-border rounded-lg input-focus text-white placeholder-gray-500"
                />
              </div>
            </div>
          )}
        </div>

        {/* Notas */}
        <div className="card">
          <label className="block text-sm font-medium text-gray-300 mb-2">Notas (Opcional)</label>
          <textarea
            value={notas}
            onChange={(e) => setNotas(e.target.value)}
            placeholder="Ej: Cliente solicitó cambio de horario, falta comprobante"
            rows={2}
            className="w-full px-4 py-2 bg-dark-bg border border-dark-border rounded-lg input-focus text-white placeholder-gray-500"
          />
        </div>

        {/* Botones */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <button
            onClick={handleGuardarPedido}
            disabled={loading}
            className="btn-primary-lg flex items-center justify-center gap-2 disabled:opacity-50"
          >
            <Send className="w-5 h-5" />
            {loading ? 'Guardando...' : 'Guardar Pedido'}
          </button>
          <button
            onClick={() => router.back()}
            className="px-8 py-4 bg-dark-card border border-dark-border hover:border-gray-400 text-white font-bold rounded-lg transition-all"
          >
            Cancelar
          </button>
        </div>
      </div>

      {/* Modal para nuevo cliente */}
      <Modal
        isOpen={newClientModalOpen}
        onClose={() => {
          setNewClientModalOpen(false);
          setError('');
        }}
        title="Agregar Nuevo Cliente"
        size="sm"
      >
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Nombre</label>
            <input
              type="text"
              value={nuevoCliente}
              onChange={(e) => setNuevoCliente(e.target.value)}
              placeholder="Nombre del cliente"
              className="w-full px-4 py-2 bg-dark-bg border border-dark-border rounded-lg input-focus text-white placeholder-gray-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Teléfono</label>
            <input
              type="tel"
              value={nuevoClienteTelefono}
              onChange={(e) => setNuevoClienteTelefono(e.target.value)}
              placeholder="+52 1234567890"
              className="w-full px-4 py-2 bg-dark-bg border border-dark-border rounded-lg input-focus text-white placeholder-gray-500"
            />
          </div>

          <div className="flex gap-2">
            <button onClick={handleAgregarCliente} className="flex-1 btn-primary-lg">
              Agregar
            </button>
            <button
              onClick={() => setNewClientModalOpen(false)}
              className="flex-1 px-4 py-2 bg-dark-card border border-dark-border hover:border-gray-400 text-white rounded-lg transition-all"
            >
              Cancelar
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
