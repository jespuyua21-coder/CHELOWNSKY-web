'use client';

import { useState, useRef } from 'react';
import { useRouter } from 'next/navigation';
import { useBusinessStore, BusinessData } from '@/lib/stores/businessStore';
import { useAuthStore } from '@/lib/stores/authStore';
import { readExcelFile } from '@/lib/excelUtils';
import { Upload, Plus } from 'lucide-react';

export default function BusinessSelectPage() {
  const router = useRouter();
  const { loginBusiness } = useAuthStore();
  const { businesses, addBusiness, loadFromExcel } = useBusinessStore();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setLoading(true);
    setError('');

    try {
      const excelData = await readExcelFile(file);

      // Crear ID único para el negocio
      const businessId = Math.random().toString(36).substr(2, 9);
      const businessName = file.name.replace('.xlsx', '').replace('.xls', '');

      const newBusiness: BusinessData = {
        id: businessId,
        nombre: businessName,
        giro: 'Vendedor',
        clientes: excelData.clientes,
        pedidos: excelData.pedidos,
        deudores: excelData.deudores,
      };

      addBusiness(newBusiness);
      loginBusiness(businessId, businessName);

      // Ir al dashboard del negocio
      router.push(`/business/${businessId}/dashboard`);
    } catch (err) {
      setError(`Error al cargar el archivo: ${err instanceof Error ? err.message : 'Desconocido'}`);
    } finally {
      setLoading(false);
      event.target.value = '';
    }
  };

  const handleSelectBusiness = (business: BusinessData) => {
    loginBusiness(business.id, business.nombre);
    router.push(`/business/${business.id}/dashboard`);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      {/* Sección de carga */}
      <div className="mb-12">
        <h2 className="text-3xl font-bold mb-6">
          Carga tu Excel <span className="text-chelonsky-400">📊</span>
        </h2>

        <div
          className="border-2 border-dashed border-dark-border rounded-xl p-8 text-center hover:border-chelonsky-400 transition-colors cursor-pointer"
          onClick={() => fileInputRef.current?.click()}
        >
          <Upload className="w-12 h-12 text-chelonsky-400 mx-auto mb-4" />
          <h3 className="text-xl font-bold mb-2">Arrastra tu archivo Excel</h3>
          <p className="text-gray-400 mb-4">O haz clic para seleccionar</p>
          <p className="text-sm text-gray-500">Soporta archivos .xlsx y .xls con datos de clientes y pedidos</p>

          <input
            ref={fileInputRef}
            type="file"
            accept=".xlsx,.xls"
            onChange={handleFileUpload}
            disabled={loading}
            className="hidden"
          />
        </div>

        {loading && (
          <div className="mt-4 text-center">
            <p className="text-chelonsky-400">Cargando archivo...</p>
          </div>
        )}

        {error && (
          <div className="mt-4 p-4 bg-red-900/20 border border-red-600 rounded-lg text-red-400">
            {error}
          </div>
        )}
      </div>

      {/* Negocios cargados */}
      {businesses.length > 0 && (
        <div>
          <h2 className="text-3xl font-bold mb-6">
            Tus Negocios <span className="text-chelonsky-400">🏪</span>
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {businesses.map((business) => (
              <button
                key={business.id}
                onClick={() => handleSelectBusiness(business)}
                className="card hover:border-chelonsky-400 cursor-pointer group text-left"
              >
                <h3 className="text-xl font-bold mb-2 group-hover:text-chelonsky-400 transition-colors">
                  {business.nombre}
                </h3>
                <p className="text-gray-400 mb-4">{business.giro}</p>

                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div className="bg-dark-bg rounded-lg p-3">
                    <p className="text-gray-400 text-sm">Clientes</p>
                    <p className="text-2xl font-bold text-chelonsky-400">
                      {business.clientes.length}
                    </p>
                  </div>
                  <div className="bg-dark-bg rounded-lg p-3">
                    <p className="text-gray-400 text-sm">Pedidos</p>
                    <p className="text-2xl font-bold text-chelonsky-400">
                      {business.pedidos.length}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 text-chelonsky-400 group-hover:gap-4 transition-all">
                  <span>Ingresar</span>
                  <span>→</span>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Mensaje vacío */}
      {businesses.length === 0 && !loading && (
        <div className="text-center py-12">
          <Plus className="w-16 h-16 text-gray-600 mx-auto mb-4" />
          <p className="text-gray-400 text-lg">
            Carga tu primer Excel para comenzar a gestionar tu negocio
          </p>
        </div>
      )}
    </div>
  );
}
