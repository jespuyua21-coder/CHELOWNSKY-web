import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'CHELONSKYSELL - Sistema de Gestión de Ventas',
  description: 'Gestiona tus ventas, clientes y deudores con Excel y WhatsApp',
  viewport: 'width=device-width, initial-scale=1, maximum-scale=1',
  themeColor: '#22c55e',
  manifest: '/manifest.json',
  appleWebApp: {
    capable: true,
    statusBarStyle: 'black-translucent',
    title: 'CHELONSKYSELL',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="es" className="dark">
      <body className="bg-dark-bg text-white antialiased">
        <div className="min-h-screen bg-premium-dark">
          {children}
        </div>
      </body>
    </html>
  );
}
