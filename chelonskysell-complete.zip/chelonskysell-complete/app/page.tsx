'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuthStore } from '@/lib/stores/authStore';
import { Modal } from '@/components/Modal';
import { Lock, Store } from 'lucide-react';

export default function HomePage() {
  const router = useRouter();
  const { isAuthenticated, isSuperAdmin } = useAuthStore();
  const [superAdminModalOpen, setSuperAdminModalOpen] = useState(false);
  const [password, setPassword] = useState('');
  const [passwordError, setPasswordError] = useState('');

  // Si ya está autenticado, redirigir
  if (isAuthenticated) {
    if (isSuperAdmin) {
      router.push('/superadmin/mis-clientes');
    } else {
      router.push('/business/dashboard');
    }
    return null;
  }

  const handleSuperAdminLogin = () => {
    const { login } = useAuthStore();
    if (login(password)) {
      setSuperAdminModalOpen(false);
      setPassword('');
      setPasswordError('');
      router.push('/superadmin/mis-clientes');
    } else {
      setPasswordError('Contraseña incorrecta');
    }
  };

  return (
    <main className="min-h-screen flex items-center justify-center p-4">
      <div className="max-w-4xl w-full">
        {/* Logo y título */}
        <div className="text-center mb-16">
          <div className="text-6xl font-bold mb-4">
            <span className="text-white">CHELONSKY</span>
            <span className="text-chelonsky-400">SELL</span>
          </div>
          <p className="text-gray-400 text-lg">
            Sistema de gestión de ventas y créditos basado en Excel
          </p>
        </div>

        {/* Tarjetas de selección */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
          {/* Opción SuperAdmin */}
          <button
            onClick={() => setSuperAdminModalOpen(true)}
            className="card hover:border-chelonsky-400 cursor-pointer group"
          >
            <div className="flex items-center justify-center w-16 h-16 bg-chelonsky-400/20 rounded-full mb-4 group-hover:bg-chelonsky-400/40 transition-all">
              <Lock className="w-8 h-8 text-chelonsky-400" />
            </div>
            <h2 className="text-2xl font-bold mb-2 group-hover:text-chelonsky-400 transition-colors">
              SUPERADMIN
            </h2>
            <p className="text-gray-400 mb-6">
              Panel de control para administradores. Gestiona tus clientes y sus suscripciones.
            </p>
            <div className="flex items-center gap-2 text-chelonsky-400 group-hover:gap-4 transition-all">
              <span>Continuar</span>
              <span>→</span>
            </div>
          </button>

          {/* Opción Business Owner */}
          <button
            onClick={() => router.push('/business')}
            className="card hover:border-chelonsky-400 cursor-pointer group"
          >
            <div className="flex items-center justify-center w-16 h-16 bg-chelonsky-400/20 rounded-full mb-4 group-hover:bg-chelonsky-400/40 transition-all">
              <Store className="w-8 h-8 text-chelonsky-400" />
            </div>
            <h2 className="text-2xl font-bold mb-2 group-hover:text-chelonsky-400 transition-colors">
              MI NEGOCIO
            </h2>
            <p className="text-gray-400 mb-6">
              Acceso a tu negocio. Gestiona pedidos, clientes, deudores y exporta tu Excel.
            </p>
            <div className="flex items-center gap-2 text-chelonsky-400 group-hover:gap-4 transition-all">
              <span>Continuar</span>
              <span>→</span>
            </div>
          </button>
        </div>

        {/* Footer */}
        <div className="text-center text-gray-500 text-sm">
          <p>CHELONSKYSELL v1.0 • Sistema PWA para gestión de ventas</p>
          <p className="mt-2">© 2024 Chelonsky Store. Todos los derechos reservados.</p>
        </div>
      </div>

      {/* Modal para contraseña SuperAdmin */}
      <Modal
        isOpen={superAdminModalOpen}
        onClose={() => {
          setSuperAdminModalOpen(false);
          setPassword('');
          setPasswordError('');
        }}
        title="Acceso SuperAdmin"
        size="sm"
      >
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Contraseña
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => {
                setPassword(e.target.value);
                setPasswordError('');
              }}
              onKeyPress={(e) => {
                if (e.key === 'Enter') {
                  handleSuperAdminLogin();
                }
              }}
              placeholder="Ingresa la contraseña"
              className="w-full px-4 py-2 bg-dark-card border border-dark-border rounded-lg focus:outline-none input-focus text-white placeholder-gray-500"
            />
            {passwordError && (
              <p className="text-red-500 text-sm mt-2">{passwordError}</p>
            )}
          </div>

          <button
            onClick={handleSuperAdminLogin}
            className="w-full btn-primary-lg"
          >
            Ingresar
          </button>
        </div>
      </Modal>
    </main>
  );
}
