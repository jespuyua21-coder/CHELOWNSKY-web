'use client';

import { useState, useRef } from 'react';
import { useBusinessStore } from '@/lib/stores/businessStore';
import { generateBusinessTemplate, generateMasterClientsFile } from '@/lib/excelUtils';
import { Modal } from '@/components/Modal';
import { Plus, Download, Eye, EyeOff } from 'lucide-react';

export default function MisClientesPage() {
  const { masterClients, setMasterClients, businesses } = useBusinessStore();
  const [showNewClientForm, setShowNewClientForm] = useState(false);
  const [newClient, setNewClient] = useState({
    nombreNegocio: '',
    giro: 'Vendedor',
    dueno: '',
    whatsapp: '',
    notas: '',
  });
  const [clientsData, setClientsData] = useState<any[]>(masterClients);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const girosDisponibles = [
    'Vendedor',
    'Licor',
    'Ropa',
    'Servicios',
    'Boletaje',
    'VIP',
    'Otro',
  ];

  const handleAgregarCliente = () => {
    if (!newClient.nombreNegocio.trim() || !newClient.dueno.trim()) {
      alert('Por favor completa: Nombre del negocio y Dueño');
      return;
    }

    const cliente = {
      id: Math.random().toString(36).substr(2, 9),
      nombreNegocio: newClient.nombreNegocio,
      giro: newClient.giro,
      dueno: newClient.dueno,
      whatsapp: newClient.whatsapp,
      fechaAlta: new Date().toISOString().split('T')[0],
      fechaProximoPago: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
        .toISOString()
        .split('T')[0],
      estado: 'Al día',
      notas: newClient.notas,
    };

    setClientsData([...clientsData, cliente]);
    setMasterClients([...clientsData, cliente]);

    // Generar Excel plantilla para el nuevo cliente
    generateBusinessTemplate(newClient.nombreNegocio, newClient.giro);

    // Resetear formulario
    setNewClient({
      nombreNegocio: '',
      giro: 'Vendedor',
      dueno: '',
      whatsapp: '',
      notas: '',
    });
    setShowNewClientForm(false);
  };

  const handleMarcarComoPagado = (id: string) => {
    const updated = clientsData.map((c) => {
      if (c.id === id) {
        return {
          ...c,
          estado: 'Al día',
          fechaProximoPago: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
            .toISOString()
            .split('T')[0],
        };
      }
      return c;
    });
    setClientsData(updated);
    setMasterClients(updated);
  };

  const handleDescargarExcel = () => {
    generateMasterClientsFile(clientsData);
  };

  const handleDelete = (id: string) => {
    const updated = clientsData.filter((c) => c.id !== id);
    setClientsData(updated);
    setMasterClients(updated);
  };

  const getEstadoColor = (estado: string) => {
    switch (estado) {
      case 'Al día':
        return 'text-green-500 bg-green-900/20';
      case 'Por vencer':
        return 'text-yellow-500 bg-yellow-900/20';
      case 'Vencido':
        return 'text-red-500 bg-red-900/20';
      default:
        return 'text-gray-400';
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-4xl font-bold">
          Mis Clientes <span className="text-chelonsky-400">👥</span>
        </h1>

        <div className="flex gap-2">
          <button
            onClick={handleDescargarExcel}
            className="flex items-center gap-2 px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-all"
          >
            <Download className="w-5 h-5" />
            Descargar Excel
          </button>

          <button
            onClick={() => setShowNewClientForm(true)}
            className="btn-primary-lg flex items-center gap-2"
          >
            <Plus className="w-5 h-5" />
            Agregar Cliente
          </button>
        </div>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="card">
          <p className="text-gray-400 text-sm mb-2">Total de Clientes</p>
          <p className="text-4xl font-bold text-chelonsky-400">{clientsData.length}</p>
        </div>
        <div className="card">
          <p className="text-gray-400 text-sm mb-2">Al día</p>
          <p className="text-4xl font-bold text-green-500">
            {clientsData.filter((c) => c.estado === 'Al día').length}
          </p>
        </div>
        <div className="card">
          <p className="text-gray-400 text-sm mb-2">Por vencer / Vencidos</p>
          <p className="text-4xl font-bold text-red-500">
            {clientsData.filter((c) => c.estado !== 'Al día').length}
          </p>
        </div>
      </div>

      {/* Tabla de clientes */}
      {clientsData.length === 0 ? (
        <div className="card text-center py-12">
          <p className="text-gray-400 text-lg">No tienes clientes agregados aún</p>
        </div>
      ) : (
        <div className="overflow-x-auto card">
          <table className="w-full">
            <thead>
              <tr className="border-b border-dark-border">
                <th className="text-left px-6 py-4 font-bold text-gray-300">Negocio</th>
                <th className="text-left px-6 py-4 font-bold text-gray-300">Giro</th>
                <th className="text-left px-6 py-4 font-bold text-gray-300">Dueño</th>
                <th className="text-left px-6 py-4 font-bold text-gray-300">Estado</th>
                <th className="text-left px-6 py-4 font-bold text-gray-300">Próx. Pago</th>
                <th className="text-left px-6 py-4 font-bold text-gray-300">Acciones</th>
              </tr>
            </thead>
            <tbody>
              {clientsData.map((client) => (
                <tr key={client.id} className="border-b border-dark-border hover:bg-dark-bg/50">
                  <td className="px-6 py-4">
                    <p className="font-bold">{client.nombreNegocio}</p>
                    <p className="text-sm text-gray-400">{client.whatsapp || 'Sin WhatsApp'}</p>
                  </td>
                  <td className="px-6 py-4 text-gray-400">{client.giro}</td>
                  <td className="px-6 py-4 text-gray-400">{client.dueno}</td>
                  <td className="px-6 py-4">
                    <span className={`px-3 py-1 rounded-full text-sm font-bold ${getEstadoColor(client.estado)}`}>
                      {client.estado}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-gray-400">{client.fechaProximoPago}</td>
                  <td className="px-6 py-4">
                    <div className="flex gap-2">
                      <button
                        onClick={() => handleMarcarComoPagado(client.id)}
                        className="px-3 py-1 bg-green-600 hover:bg-green-700 text-white rounded text-sm transition-all"
                      >
                        ✓ Pagado
                      </button>
                      <button
                        onClick={() => handleDelete(client.id)}
                        className="px-3 py-1 bg-red-600 hover:bg-red-700 text-white rounded text-sm transition-all"
                      >
                        Eliminar
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Modal para agregar cliente */}
      <Modal
        isOpen={showNewClientForm}
        onClose={() => setShowNewClientForm(false)}
        title="Agregar Nuevo Cliente"
        size="lg"
      >
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Nombre del Negocio *
            </label>
            <input
              type="text"
              value={newClient.nombreNegocio}
              onChange={(e) =>
                setNewClient({ ...newClient, nombreNegocio: e.target.value })
              }
              placeholder="Ej: La Tienda de Don Juan"
              className="w-full px-4 py-2 bg-dark-bg border border-dark-border rounded-lg input-focus text-white placeholder-gray-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Giro</label>
            <select
              value={newClient.giro}
              onChange={(e) => setNewClient({ ...newClient, giro: e.target.value })}
              className="w-full px-4 py-2 bg-dark-bg border border-dark-border rounded-lg input-focus text-white"
            >
              {girosDisponibles.map((giro) => (
                <option key={giro} value={giro}>
                  {giro}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Dueño *</label>
            <input
              type="text"
              value={newClient.dueno}
              onChange={(e) => setNewClient({ ...newClient, dueno: e.target.value })}
              placeholder="Nombre del dueño"
              className="w-full px-4 py-2 bg-dark-bg border border-dark-border rounded-lg input-focus text-white placeholder-gray-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">WhatsApp</label>
            <input
              type="tel"
              value={newClient.whatsapp}
              onChange={(e) => setNewClient({ ...newClient, whatsapp: e.target.value })}
              placeholder="+52 1234567890"
              className="w-full px-4 py-2 bg-dark-bg border border-dark-border rounded-lg input-focus text-white placeholder-gray-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Notas</label>
            <textarea
              value={newClient.notas}
              onChange={(e) => setNewClient({ ...newClient, notas: e.target.value })}
              placeholder="Notas adicionales"
              rows={2}
              className="w-full px-4 py-2 bg-dark-bg border border-dark-border rounded-lg input-focus text-white placeholder-gray-500"
            />
          </div>

          <div className="flex gap-2">
            <button onClick={handleAgregarCliente} className="flex-1 btn-primary-lg">
              Crear Cliente y Plantilla
            </button>
            <button
              onClick={() => setShowNewClientForm(false)}
              className="flex-1 px-4 py-2 bg-dark-card border border-dark-border hover:border-gray-400 text-white rounded-lg transition-all"
            >
              Cancelar
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
