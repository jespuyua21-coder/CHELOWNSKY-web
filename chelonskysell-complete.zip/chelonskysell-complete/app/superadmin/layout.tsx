'use client';

import { useAuthStore } from '@/lib/stores/authStore';
import { useRouter } from 'next/navigation';
import { Header } from '@/components/Header';
import { useEffect } from 'react';

export default function SuperAdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const { isAuthenticated, isSuperAdmin } = useAuthStore();
  const router = useRouter();

  useEffect(() => {
    if (!isAuthenticated || !isSuperAdmin) {
      router.push('/');
    }
  }, [isAuthenticated, isSuperAdmin, router]);

  if (!isAuthenticated || !isSuperAdmin) {
    return null;
  }

  return (
    <>
      <Header />
      <main className="min-h-screen bg-premium-dark">
        {children}
      </main>
    </>
  );
}
