# 🏪 Guía de Usuario - CHELONSKYSELL para Tu Negocio

**Bienvenido a CHELONSKYSELL** - Tu sistema de gestión de ventas y créditos 100% en tu control.

## 🎯 ¿Qué es CHELONSKYSELL?

Es una aplicación para que **registres tus ventas, clientes y dinero que te deben** de forma rápida y fácil:

- ✅ Crea pedidos en menos de 30 segundos
- 📍 Captura ubicación automática (GPS)
- 💬 Envía pedidos a tu grupo de WhatsApp
- 💰 Controla quién te debe dinero
- 📊 Descarga Excel con todos tus datos

## 🚀 Tu Primer Pedido (5 minutos)

### 1. Abre la app
```
Abre tu navegador y ve a: http://localhost:3000
o instala como app en tu celular
```

### 2. Selecciona "MI NEGOCIO"
- Si tienes Excel anterior: Cárgalo (arrastra o click)
- Si es primera vez: Pide plantilla al SuperAdmin

### 3. Haz clic en "Nuevo Pedido 📦"

### 4. Completa rápidamente:
```
Cliente:         Juan Pérez (busca o agrega nuevo)
Ubicación:       [Botón AZUL GRANDE] Usar mi ubicación actual
Descripción:     2x Cerveza Corona, 1x Refresco
Monto:           $450
Estado de pago:  ✅ Pagado  |  🔴 Prestado  |  ⏳ Abono
```

### 5. Haz clic en "Guardar Pedido"
- ✅ El pedido se guarda
- 💬 **WhatsApp se abre automáticamente** con el mensaje formateado
- 📌 Copiar a tu grupo de trabajo/repartidores

## 📊 Tu Dashboard

Cada vez que abres la app, ves dos cosas importantes:

### 🔴 DEUDORES (Quién te debe dinero)
```
Juan Pérez:      $1,500 owed
  [Llamar]  [WhatsApp] → Recordar pago

María García:    $800 owed
  [Llamar]  [WhatsApp] → Recordar pago
```
Los que más deben aparecen primero.

**Acciones rápidas:**
- **Llamar**: Abre llamada telefónica
- **WhatsApp**: Envía recordatorio de pago

### ⭐ MEJORES CLIENTES (Tus mejores ventas)
```
Roberto López:   $12,500 total gastado
  [Ver Detalles]

Carlos Sánchez:  $9,200 total gastado
  [Ver Detalles]
```
Clientes que más dinero han gastado contigo.

**Acción:**
- Atenlos especialmente, son VIP para ti

## 💰 Estados de Pago Explicados

Cuando registras un pedido, elige:

### ✅ PAGADO
```
El cliente pagó el dinero completo en el acto.
❌ No aparece en deudores
✅ Se cuenta como venta completada
```

### 🔴 PRESTADO
```
El cliente se lleva la mercancía SIN pagar.
❌ Promete pagar después (mañana, semana que viene)
⚠️ Aparece en DEUDORES con la deuda completa
💬 Usa WhatsApp para recordar pago
```

### ⏳ ABONO PARCIAL
```
El cliente pagó parte, falta resto.
Ejemplo: Pedido $500, pagó $200
💬 Deuda pendiente: $300
📝 Puedes registrar cuánto pagó
```

## 📍 Geolocalización (Ubicación GPS)

### ¿Para qué sirve?
```
Saber DÓNDE se hizo cada venta para:
- Verificar ruta de repartidores
- Saber dónde volvió a comprar el cliente
- Documentar entregas
```

### ¿Cómo usar?
```
1. Abre un nuevo pedido
2. VE EL BOTÓN AZUL GIGANTE: "📍 Usar mi ubicación actual"
3. Haz clic → Tu celular pide permiso
4. Aprueба → ¡Se rellena automáticamente!
5. Generá un link de Google Maps → Comparte con repartidores
```

### ¿Qué información captura?
```
✅ Latitud y Longitud (coordenadas GPS exactas)
✅ Link de Google Maps (pueden ver dónde fue)
❌ NO captura nombre de dirección (eso lo escribes tú)
```

## 💬 Cómo Enviar Pedidos por WhatsApp

### Paso a paso:
```
1. Creas el pedido (cliente, monto, descripción)
2. Haces clic "Guardar Pedido"
3. ✨ Se abre WhatsApp automáticamente
4. El mensaje ya viene formateado:

   📦 PEDIDO #001
   👤 Cliente: Juan Pérez
   📍 Ubicación: Calle 5 Mayo #123 — Ver mapa
   📝 Descripción: 2x Cerveza Corona
   💰 Monto: $450
   Estado: ✅ Pagado
   
5. Copias y pegas en tu grupo de trabajo
6. ¡Listo! Tus repartidores ya vieron el pedido con ubicación
```

### Ventajas:
- ✅ No escribes manualmente
- ✅ Información completa y ordenada
- ✅ Link de mapa incluido
- ✅ Se ve profesional

## 🧑‍💼 Agregar Clientes Nuevos

### Mientras haces un pedido:
```
1. Estás en "Nuevo Pedido"
2. En cliente, selecciona "Nuevo" (botón verde +)
3. Completa:
   Nombre:    Juan Pérez
   Teléfono:  +52 1234567890
4. Click "Agregar"
5. Continúa con el pedido
```

### Toma 10 segundos, sin formularios complicados

## 📥 Descargar Mi Excel Actualizado

### ¿Por qué descargar?
```
✅ Backup de tus datos
✅ Compartir con contador/abogado
✅ Análisis en Excel
✅ Seguridad (por si se borra cache)
```

### Cómo hacerlo:
```
1. En el dashboard, busca botón azul:
   "⬇️ Descargar Excel Actualizado"
2. Haz clic
3. Se descarga archivo: MiNegocio_2024-01-15.xlsx
4. Ábrelo en Excel para ver todos tus datos
```

### Qué contiene:
```
📊 Dashboard: Resumen (clientes, pedidos, deuda total)
👥 Clientes: Nombre, teléfono, deuda, total gastado
📦 Pedidos: Todos los registros con detalles
💰 Deudores: Solo los que te deben (calculado automático)
⚙️ Config: Configuración de tu negocio
```

## 🎛️ Cambiar Estado de un Pedido

¿Registraste un pedido como "Prestado" pero el cliente pagó? Cambiar es fácil:

### En el Dashboard:
```
1. Busca al cliente en "Deudores"
2. Haz clic en su tarjeta
3. Verás todos sus pedidos pendientes
4. Selecciona el pedido
5. Botón "Marcar como Pagado"
6. ✅ Se quita de deudores automáticamente
```

## 📱 Instalar como App en Celular

CHELONSKYSELL es una PWA - ¡se instala como app!

### En iPhone:
```
1. Abre Safari (no Chrome)
2. Ve a: tu-url-aquí.com
3. Botón abajo: Compartir (cuadrado + flecha)
4. "Agregar a pantalla de inicio"
5. Nombre: CHELONSKYSELL
6. Agregar → Listo
```

### En Android:
```
1. Abre Chrome
2. Ve a: tu-url-aquí.com
3. Menú (3 puntos arriba)
4. "Instalar aplicación"
5. Confirmar → Listo
```

### ¿Qué ventaja?
- ✅ Acceso rápido desde pantalla principal
- ✅ Funciona offline (con datos guardados)
- ✅ Sin necesidad de ir al navegador
- ✅ Se ve como una app "real"

## ⚙️ Configuración de Mi Negocio

Aunque CHELONSKYSELL es simple, puedes personalizar:

### Color del negocio:
```
Por defecto: Verde neon (#22c55e)
Puedes cambiar en Settings (cuando esté disponible)
```

### Moneda:
```
Por defecto: Pesos Mexicanos (MXN)
Formato: $1,234.56
```

### Zona horaria:
```
Por defecto: Hora de México
Se ajusta automáticamente
```

## 🔒 Seguridad y Datos

### ¿Dónde se guardan mis datos?
```
✅ En tu navegador (local)
❌ NO se envían a servidores externos
❌ NO hay nube
= MÁS PRIVACIDAD
```

### ¿Qué pasa si limpio el cache?
```
⚠️ Los datos se pierden
SOLUCIÓN: Descarga Excel regularmente
👉 Es tu backup principal
```

### ¿Y si cambio de teléfono?
```
1. En teléfono antiguo: Descarga Excel
2. En teléfono nuevo: Carga el Excel
3. Continúas exactamente donde dejaste
```

## 💡 Tips y Trucos

### 🚀 Crear pedido ultra rápido
```
1. Tienes cliente guardado → 10 segundos
2. USA botón GPS para ubicación automática
3. Texto en descripción (no es formulario)
4. Monto número solo
5. Estado: 1 clic
= Pedido creado en 30 segundos
```

### 📍 Ubicación se repite
```
Si estás en el mismo lugar, el GPS 
detecta la misma ubicación.
Puedes editarla manualmente si necesitas
diferente dirección.
```

### 💬 WhatsApp para varios
```
El mensaje se abre para TÍ
Copias y pegas en:
- Grupo de repartidores
- Grupo de equipo
- Directamente a cliente
```

### 📊 Analizar datos
```
Descarga Excel cada semana
Abre en Excel Desktop
Usa gráficos y tablas dinámicas
Análisis profesional de tu negocio
```

## ❓ Preguntas Frecuentes

### ¿Cuántos clientes puedo registrar?
✅ Ilimitados. No hay restricción.

### ¿Cuántos pedidos puedo hacer?
✅ Ilimitados. La app es rápida incluso con miles.

### ¿Se sincroniza en varios dispositivos?
❌ Actualmente no. Cada dispositivo es independiente.
✅ Próxima versión: Sincronización en cloud.

### ¿Funciona sin internet?
⚠️ La app sí, pero WhatsApp necesita conexión.

### ¿Puedo cambiar mi contraseña?
✅ Sí. Pídela al SuperAdmin.

### ¿Dónde está la opción de editar cliente?
📝 Próxima versión. Actualmente re-agregas.

### ¿Puedo añadir más detalles al pedido?
✅ Campo de "Notas" → escribe lo que necesites.

## 🆘 Problemas Comunes

### "Geolocalización no funciona"
```
1. Verifica permiso en navegador
2. Usa incógnito si está negado
3. Probada en Chrome, Safari, Firefox
```

### "WhatsApp no se abre"
```
1. ¿Tienes WhatsApp instalado?
2. ¿Navegador permite popups? Habilita
3. En escritorio: WhatsApp Web (web.whatsapp.com)
```

### "Los datos desaparecieron"
```
⚠️ Limpiaste cache/cookies
SOLUCIÓN: Restaurar de Excel descargado
PREVENCIÓN: Descarga cada semana
```

### "La app está lenta"
```
1. Borra cache (F12 → Aplicación → Almacenamiento)
2. Recarga página
3. Reinicia navegador
```

## 📞 Contacto y Soporte

¿Tienes problemas que no están aquí?

```
1️⃣ Revisa esta guía nuevamente
2️⃣ Pregunta al SuperAdmin (Jesús)
3️⃣ Si es error técnico: Abre issue en GitHub
```

---

## 🎉 ¡Felicidades!

Ahora sabes cómo usar CHELONSKYSELL. 

**Resumen rápido:**
- 📦 Nuevo Pedido → 30 segundos
- 📍 GPS Automático → profesional
- 💬 WhatsApp Integrado → eficiente
- 💾 Excel Descargable → seguridad

**¡Comienza a vender!**

---

**Versión**: 1.0.0 | **Última actualización**: Enero 2024

*Hecho con ❤️ por Chelonsky Store*
