# 📦 Guía de Instalación CHELONSKYSELL - Paso a Paso

Esta guía te ayudará a instalar y ejecutar CHELONSKYSELL en tu computadora.

## 🔧 Requisitos del Sistema

Antes de empezar, verifica que tengas:

### Windows
- Windows 10 o 11
- 4 GB de RAM mínimo
- 500 MB de espacio disco
- Navegador moderno (Chrome, Edge, Firefox)

### Mac
- macOS 10.13 o posterior
- 4 GB de RAM mínimo
- 500 MB de espacio disco
- Navegador moderno

### Linux
- Ubuntu 18.04+ o equivalente
- 4 GB de RAM mínimo
- 500 MB de espacio disco
- Navegador moderno

## 📥 Paso 1: Descargar e Instalar Node.js

Node.js es **obligatorio** para ejecutar CHELONSKYSELL.

### Opción A: Descargar desde web (Recomendado)

1. Ve a [https://nodejs.org](https://nodejs.org)
2. Descarga la versión **LTS** (Long Term Support) - versión 20.x o superior
3. Abre el instalador (archivo .msi en Windows, .pkg en Mac)
4. Sigue los pasos del instalador:
   - Acepta los términos
   - Elige instalación estándar
   - Finaliza

### Verificar que Node.js está instalado

Abre una terminal/consola y escribe:
```bash
node --version
npm --version
```

Debe mostrar versiones. Si muestra error, reinicia la computadora.

## 📂 Paso 2: Descargar CHELONSKYSELL

### Opción A: Descargar ZIP (Más fácil)

1. Ve a la página del proyecto en GitHub (o donde esté alojado)
2. Haz clic en **"Code"** → **"Download ZIP"**
3. Guarda el archivo
4. Extrae el ZIP en una carpeta (por ejemplo, `Documentos/chelonskysell`)

### Opción B: Usar Git (Para desarrolladores)

```bash
git clone https://github.com/tuusuario/chelonskysell.git
cd chelonskysell
```

## 📍 Paso 3: Navegar a la Carpeta del Proyecto

Abre una terminal/consola:

### En Windows (PowerShell)
```powershell
cd "C:\Users\TuUsuario\Documents\chelonskysell"
```

### En Mac/Linux
```bash
cd ~/Documents/chelonskysell
```

O simplemente:
- Abre la carpeta en explorador
- Click derecho → "Abrir Terminal Aquí" (puede variar según SO)

## 🔨 Paso 4: Instalar Dependencias

Escribe en la terminal:
```bash
npm install
```

**Esto es importante**: Espera a que termine completamente. Puede tomar 1-3 minutos.

Verás un montón de líneas siendo descargadas. Cuando termine, deberías ver algo como:
```
added 250+ packages in 2m
```

Si hay errores, intenta:
```bash
npm install --legacy-peer-deps
```

## ⚙️ Paso 5: Configurar Contraseña (Opcional)

Por defecto, la contraseña SuperAdmin es: **CHELONSKY2024**

Si quieres cambiarla:

1. Abre el archivo `.env.example` con un editor de texto
2. Cambia el valor:
```
NEXT_PUBLIC_SUPER_ADMIN_PASSWORD=CHELONSKY2024
```
por tu contraseña preferida

3. Guarda el archivo como `.env.local` (sin la extensión .example)

## 🚀 Paso 6: Iniciar la Aplicación

Escribe en la terminal:
```bash
npm run dev
```

Verás algo como:
```
> next dev
...
▲ Next.js 14.0.0
- Local:        http://localhost:3000
```

**¡Éxito!** La app se abrirá automáticamente en tu navegador.

Si no se abre automáticamente, abre tu navegador y ve a: **http://localhost:3000**

## 🎯 Primer Uso

### Como Business Owner
1. En la pantalla de inicio, haz clic en **"MI NEGOCIO"**
2. Carga tu archivo Excel (o crea uno nuevo con el wizard del SuperAdmin)
3. ¡Comienza a crear pedidos!

### Como SuperAdmin
1. Haz clic en **"SUPERADMIN"**
2. Ingresa la contraseña (CHELONSKY2024 o la que configuraste)
3. Agrega tus primeros clientes
4. Se generarán automáticamente plantillas Excel

## ✅ Checklists de Instalación

### Si todo funciona:
- ✅ Ves la pantalla de inicio de CHELONSKYSELL
- ✅ Puedes ingresar a SUPERADMIN
- ✅ Puedes cargar un Excel en MI NEGOCIO
- ✅ Los datos se cargan correctamente

### Si algo no funciona:

**Error: "node: command not found"**
- Node.js no está instalado correctamente
- Solución: Reinicia la computadora y verifica la instalación

**Error: "Port 3000 is already in use"**
- Otro programa usa el puerto 3000
- Solución: 
```bash
npm run dev -- -p 3001
```
(Usa puerto 3001 en lugar de 3000)

**Error: "EACCES permission denied"**
- Problema de permisos en Mac/Linux
- Solución:
```bash
sudo npm install
npm run dev
```

**La app se abre pero está en blanco**
- Espera 10 segundos (se está compilando)
- Si persiste: Presiona F12 (abrir developer tools)
- Mira si hay errores en la consola roja
- Reporta el error

## 📱 Ejecutar en Teléfono (Mismo WiFi)

Para probar en tu celular mientras desarrollas:

1. Abre terminal/consola en la carpeta del proyecto
2. Escribe:
```bash
npm run dev -- -H 0.0.0.0
```

3. Abre otra terminal y escribe:
```bash
ipconfig
```
(En Windows)
```bash
ifconfig
```
(En Mac/Linux)

4. Busca tu dirección IP (algo como 192.168.1.100)
5. En tu celular, abre el navegador y ve a:
```
http://192.168.1.100:3000
```

(Reemplaza 192.168.1.100 con tu IP real)

## 🏗️ Construir para Producción

Cuando esté listo para publicar online:

```bash
npm run build
npm start
```

Esto crea una versión optimizada de la app lista para deployment.

## 🗂️ Estructura de Carpetas

Después de instalar, veras:
```
chelonskysell/
├── app/                 # Páginas y rutas
│   ├── page.tsx        # Página de inicio
│   ├── business/       # Rutas del Business Owner
│   ├── superadmin/     # Rutas del SuperAdmin
│   └── layout.tsx      # Layout principal
├── components/         # Componentes React reutilizables
├── lib/               # Lógica y utilidades
│   ├── stores/        # Estado Zustand
│   ├── excelUtils.ts  # Manejo de Excel
│   └── ...
├── public/            # Archivos estáticos (manifest, favicon)
├── node_modules/      # Dependencias instaladas
├── package.json       # Configuración npm
├── tailwind.config.js # Estilos Tailwind
├── tsconfig.json      # Configuración TypeScript
└── README.md          # Documentación
```

## 📚 Próximos Pasos

Una vez instalado:

1. **Lee el README.md** para entender todas las funciones
2. **Carga tu primer Excel** en modo Business Owner
3. **Crea tu primer pedido** y prueba la geolocalización
4. **Envía un pedido por WhatsApp** para ver integración
5. **Como SuperAdmin**: Agrega un cliente y descarga la plantilla

## 💡 Tips Útiles

- **Ctrl+C en terminal**: Detiene la app (puedes volver a ejecutar con `npm run dev`)
- **F5 en navegador**: Recarga la página
- **F12**: Abre herramientas de desarrollador (para ver errores)
- **LocalStorage**: Los datos se guardan en el navegador (no en un servidor)
- **Descarga Excel regularmente**: Para tener backup de tus datos

## 🆘 Ayuda Adicional

Si tienes problemas:

1. Revisa esta guía nuevamente
2. Comprueba que Node.js está instalado (`node --version`)
3. Intenta borrar `node_modules` y reinstalar:
```bash
rm -r node_modules package-lock.json
npm install
```

4. Usa un navegador diferente (Chrome recomendado)
5. Pregunta en los comentarios/issues del proyecto

---

**¡Listo!** Deberías tener CHELONSKYSELL funcionando. 🎉

¿Tienes dudas? ¡Pregunta sin vergüenza! El proyecto está diseñado para ser simple.
