/**
 * Interfaz para coordenadas GPS
 */
export interface GpsCoordinates {
  latitud: number;
  longitud: number;
  precisión: number;
  timestamp: number;
}

/**
 * Obtiene la ubicación actual del dispositivo
 */
export function getCurrentLocation(): Promise<GpsCoordinates> {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error('Geolocalización no disponible en este navegador'));
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        resolve({
          latitud: position.coords.latitude,
          longitud: position.coords.longitude,
          precisión: position.coords.accuracy,
          timestamp: position.timestamp,
        });
      },
      (error) => {
        const errorMessages: { [key: number]: string } = {
          1: 'Permiso de ubicación denegado. Por favor, habilita la ubicación en tu dispositivo.',
          2: 'No se pudo obtener la ubicación. Intenta nuevamente.',
          3: 'El tiempo para obtener la ubicación expiró. Intenta nuevamente.',
        };
        reject(new Error(errorMessages[error.code] || 'Error al obtener ubicación'));
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 0,
      }
    );
  });
}

/**
 * Genera un enlace de Google Maps basado en coordenadas
 */
export function generateGoogleMapsLink(latitud: number, longitud: number): string {
  return `https://maps.google.com/?q=${latitud},${longitud}`;
}

/**
 * Genera una dirección legible basada en coordenadas (aproximada)
 */
export function formatCoordinates(latitud: number, longitud: number): string {
  return `${latitud.toFixed(6)}, ${longitud.toFixed(6)}`;
}

/**
 * Calcula la distancia aproximada entre dos puntos (en km, usando fórmula de Haversine)
 */
export function calculateDistance(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371; // Radio de la Tierra en km
  const dLat = (lat2 - lat1) * (Math.PI / 180);
  const dLon = (lon2 - lon1) * (Math.PI / 180);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * (Math.PI / 180)) *
      Math.cos(lat2 * (Math.PI / 180)) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

/**
 * Obtiene información de ubicación aproximada (solo coordenadas, sin API de terceros)
 */
export function getLocationInfo(coords: GpsCoordinates): {
  coordenadas: string;
  mapa: string;
  precision: string;
} {
  const coordenadas = formatCoordinates(coords.latitud, coords.longitud);
  const mapa = generateGoogleMapsLink(coords.latitud, coords.longitud);
  const precision = `±${Math.round(coords.precisión)}m`;

  return { coordenadas, mapa, precision };
}
