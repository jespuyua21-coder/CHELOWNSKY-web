import * as XLSX from 'xlsx';
import { BusinessData, Pedido, Cliente } from './stores/businessStore';

export interface ExcelData {
  clientes: Cliente[];
  pedidos: Pedido[];
  deudores: { [key: string]: number };
}

/**
 * Lee un archivo Excel y extrae datos para el negocio
 */
export async function readExcelFile(file: File): Promise<ExcelData> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    
    reader.onload = (e) => {
      try {
        const data = e.target?.result;
        const workbook = XLSX.read(data, { type: 'array' });
        
        const clientes: Cliente[] = [];
        const pedidos: Pedido[] = [];
        const deudores: { [key: string]: number } = {};

        // Leer hoja de Clientes
        if (workbook.SheetNames.includes('Clientes')) {
          const clientesSheet = workbook.Sheets['Clientes'];
          const clientesData = XLSX.utils.sheet_to_json(clientesSheet);
          
          clientesData.forEach((row: any) => {
            if (row.id || row.nombre) {
              clientes.push({
                id: row.id || Math.random().toString(),
                nombre: row.nombre || '',
                telefono: row.telefono || '',
                deuda: row.deuda || 0,
                totalGastado: row.totalGastado || 0,
              });
            }
          });
        }

        // Leer hoja de Pedidos
        if (workbook.SheetNames.includes('Pedidos')) {
          const pedidosSheet = workbook.Sheets['Pedidos'];
          const pedidosData = XLSX.utils.sheet_to_json(pedidosSheet);
          
          pedidosData.forEach((row: any) => {
            if (row.id || row.numero) {
              const pedido: Pedido = {
                id: row.id || Math.random().toString(),
                numero: row.numero || '',
                clienteId: row.clienteId || '',
                clienteNombre: row.clienteNombre || '',
                clienteTelefono: row.clienteTelefono || '',
                descripcion: row.descripcion || '',
                monto: parseFloat(row.monto) || 0,
                estado: row.estado || 'pagado',
                montoAbono: row.montoAbono ? parseFloat(row.montoAbono) : undefined,
                fechaCreacion: row.fechaCreacion || new Date().toISOString(),
                notas: row.notas || '',
              };

              if (row.latitud && row.longitud) {
                pedido.ubicacion = {
                  latitud: parseFloat(row.latitud),
                  longitud: parseFloat(row.longitud),
                  direccion: row.direccion || '',
                  linkMaps: row.linkMaps || '',
                };
              }

              pedidos.push(pedido);
            }
          });
        }

        // Calcular deudores
        pedidos.forEach((p) => {
          if (p.estado === 'prestado') {
            deudores[p.clienteId] = (deudores[p.clienteId] || 0) + p.monto;
          } else if (p.estado === 'abono_parcial') {
            deudores[p.clienteId] = (deudores[p.clienteId] || 0) + (p.monto - (p.montoAbono || 0));
          }
        });

        resolve({ clientes, pedidos, deudores });
      } catch (error) {
        reject(error);
      }
    };

    reader.onerror = () => reject(new Error('Error al leer el archivo'));
    reader.readAsArrayBuffer(file);
  });
}

/**
 * Genera un archivo Excel con los datos actuales del negocio
 */
export function generateExcelFile(business: BusinessData): void {
  const workbook = XLSX.utils.book_new();

  // Hoja de Dashboard (resumen)
  const dashboardData = [
    { Métrica: 'Total de Clientes', Valor: business.clientes.length },
    { Métrica: 'Total de Pedidos', Valor: business.pedidos.length },
    { Métrica: 'Deuda Total', Valor: Object.values(business.deudores).reduce((a, b) => a + b, 0) },
    { Métrica: 'Fecha de Generación', Valor: new Date().toLocaleString('es-MX') },
  ];
  const dashboardSheet = XLSX.utils.json_to_sheet(dashboardData);
  XLSX.utils.book_append_sheet(workbook, dashboardSheet, 'Dashboard');

  // Hoja de Clientes
  const clientesSheet = XLSX.utils.json_to_sheet(business.clientes);
  XLSX.utils.book_append_sheet(workbook, clientesSheet, 'Clientes');

  // Hoja de Pedidos
  const pedidosData = business.pedidos.map((p) => ({
    id: p.id,
    numero: p.numero,
    clienteId: p.clienteId,
    clienteNombre: p.clienteNombre,
    clienteTelefono: p.clienteTelefono,
    descripcion: p.descripcion,
    monto: p.monto,
    estado: p.estado,
    montoAbono: p.montoAbono,
    latitud: p.ubicacion?.latitud,
    longitud: p.ubicacion?.longitud,
    direccion: p.ubicacion?.direccion,
    linkMaps: p.ubicacion?.linkMaps,
    fechaCreacion: p.fechaCreacion,
    notas: p.notas,
  }));
  const pedidosSheet = XLSX.utils.json_to_sheet(pedidosData);
  XLSX.utils.book_append_sheet(workbook, pedidosSheet, 'Pedidos');

  // Hoja de Deudores
  const deudoresData = Object.entries(business.deudores)
    .filter(([_, monto]) => monto > 0)
    .map(([clienteId, monto]) => {
      const cliente = business.clientes.find((c) => c.id === clienteId);
      return {
        clienteId,
        clienteNombre: cliente?.nombre || 'Desconocido',
        clienteTelefono: cliente?.telefono || '',
        deuda: monto,
      };
    });
  const deudoresSheet = XLSX.utils.json_to_sheet(deudoresData);
  XLSX.utils.book_append_sheet(workbook, deudoresSheet, 'Deudores');

  // Descargar
  const fileName = `${business.nombre}_${new Date().toISOString().split('T')[0]}.xlsx`;
  XLSX.writeFile(workbook, fileName);
}

/**
 * Genera un archivo Excel plantilla para un nuevo negocio
 */
export function generateBusinessTemplate(nombre: string, giro: string): void {
  const workbook = XLSX.utils.book_new();

  // Dashboard
  const dashboardData = [
    { Métrica: 'Negocio', Valor: nombre },
    { Métrica: 'Giro', Valor: giro },
    { Métrica: 'Fecha de Inicio', Valor: new Date().toLocaleString('es-MX') },
    { Métrica: 'Estado', Valor: 'Activo' },
  ];
  const dashboardSheet = XLSX.utils.json_to_sheet(dashboardData);
  XLSX.utils.book_append_sheet(workbook, dashboardSheet, 'Dashboard');

  // Clientes (vacío)
  const clientesSheet = XLSX.utils.json_to_sheet([
    { id: '1', nombre: 'Ejemplo Cliente 1', telefono: '+52123456789', deuda: 0, totalGastado: 1000 },
  ]);
  XLSX.utils.book_append_sheet(workbook, clientesSheet, 'Clientes');

  // Pedidos (vacío)
  const pedidosSheet = XLSX.utils.json_to_sheet([
    {
      id: '1',
      numero: 'PED-001',
      clienteId: '1',
      clienteNombre: 'Ejemplo Cliente 1',
      clienteTelefono: '+52123456789',
      descripcion: 'Ejemplo de producto',
      monto: 500,
      estado: 'pagado',
      montoAbono: null,
      latitud: null,
      longitud: null,
      direccion: '',
      linkMaps: '',
      fechaCreacion: new Date().toISOString(),
      notas: '',
    },
  ]);
  XLSX.utils.book_append_sheet(workbook, pedidosSheet, 'Pedidos');

  // Deudores
  const deudoresSheet = XLSX.utils.json_to_sheet([
    { clienteId: '', clienteNombre: '', clienteTelefono: '', deuda: 0 },
  ]);
  XLSX.utils.book_append_sheet(workbook, deudoresSheet, 'Deudores');

  // Config
  const configSheet = XLSX.utils.json_to_sheet([
    { propiedad: 'colorPrimario', valor: '#22c55e' },
    { propiedad: 'colorSecundario', valor: '#0f0f0f' },
    { propiedad: 'tipografiaPreferida', valor: 'Segoe UI' },
    { propiedad: 'monedaPais', valor: 'MXN' },
    { propiedad: 'codigoPais', valor: '+52' },
  ]);
  XLSX.utils.book_append_sheet(workbook, configSheet, 'Config');

  const fileName = `${nombre}_Template_${new Date().toISOString().split('T')[0]}.xlsx`;
  XLSX.writeFile(workbook, fileName);
}

/**
 * Genera un Excel maestro para SuperAdmin con lista de clientes
 */
export function generateMasterClientsFile(clients: any[]): void {
  const workbook = XLSX.utils.book_new();

  const masterData = clients.map((c) => ({
    id: c.id,
    nombreNegocio: c.nombreNegocio,
    giro: c.giro,
    dueno: c.dueno,
    whatsapp: c.whatsapp,
    fechaAlta: c.fechaAlta,
    fechaProximoPago: c.fechaProximoPago,
    estado: c.estado,
    notas: c.notas,
  }));

  const sheet = XLSX.utils.json_to_sheet(masterData);
  XLSX.utils.book_append_sheet(workbook, sheet, 'Clientes');

  const fileName = `CHELONSKYSELL_Mis_Clientes_${new Date().toISOString().split('T')[0]}.xlsx`;
  XLSX.writeFile(workbook, fileName);
}
