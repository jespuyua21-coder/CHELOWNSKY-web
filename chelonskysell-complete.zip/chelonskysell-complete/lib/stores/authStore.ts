import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface AuthState {
  isAuthenticated: boolean;
  isSuperAdmin: boolean;
  currentBusinessId: string | null;
  businessName: string | null;
  login: (password: string) => boolean;
  loginBusiness: (businessId: string, businessName: string) => void;
  logout: () => void;
}

const SUPER_ADMIN_PASSWORD = process.env.NEXT_PUBLIC_SUPER_ADMIN_PASSWORD || 'CHELONSKY2024';

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      isAuthenticated: false,
      isSuperAdmin: false,
      currentBusinessId: null,
      businessName: null,

      login: (password: string) => {
        if (password === SUPER_ADMIN_PASSWORD) {
          set({
            isAuthenticated: true,
            isSuperAdmin: true,
            currentBusinessId: null,
          });
          return true;
        }
        return false;
      },

      loginBusiness: (businessId: string, businessName: string) => {
        set({
          isAuthenticated: true,
          isSuperAdmin: false,
          currentBusinessId: businessId,
          businessName: businessName,
        });
      },

      logout: () => {
        set({
          isAuthenticated: false,
          isSuperAdmin: false,
          currentBusinessId: null,
          businessName: null,
        });
      },
    }),
    {
      name: 'auth-storage',
    }
  )
);
