import { create } from 'zustand';

export interface Cliente {
  id: string;
  nombre: string;
  telefono: string;
  deuda?: number;
  totalGastado?: number;
}

export interface Pedido {
  id: string;
  numero: string;
  clienteId: string;
  clienteNombre: string;
  clienteTelefono: string;
  descripcion: string;
  monto: number;
  estado: 'pagado' | 'prestado' | 'abono_parcial';
  montoAbono?: number;
  ubicacion?: {
    latitud: number;
    longitud: number;
    direccion: string;
    linkMaps: string;
  };
  fechaCreacion: string;
  notas?: string;
}

export interface BusinessData {
  id: string;
  nombre: string;
  giro: string;
  logo?: string;
  clientes: Cliente[];
  pedidos: Pedido[];
  deudores: { [key: string]: number };
}

interface BusinessStore {
  businesses: BusinessData[];
  masterClients: any[];
  addBusiness: (business: BusinessData) => void;
  addPedido: (businessId: string, pedido: Pedido) => void;
  updatePedidoEstado: (businessId: string, pedidoId: string, estado: string, montoAbono?: number) => void;
  addCliente: (businessId: string, cliente: Cliente) => void;
  setMasterClients: (clients: any[]) => void;
  loadFromExcel: (businessId: string, data: any) => void;
}

export const useBusinessStore = create<BusinessStore>((set, get) => ({
  businesses: [],
  masterClients: [],

  addBusiness: (business: BusinessData) => {
    set((state) => ({
      businesses: [...state.businesses, business],
    }));
  },

  addPedido: (businessId: string, pedido: Pedido) => {
    set((state) => ({
      businesses: state.businesses.map((b) => {
        if (b.id === businessId) {
          // Actualizar deudores si es prestado o abono
          const newDeudores = { ...b.deudores };
          if (pedido.estado === 'prestado') {
            newDeudores[pedido.clienteId] = (newDeudores[pedido.clienteId] || 0) + pedido.monto;
          } else if (pedido.estado === 'abono_parcial') {
            newDeudores[pedido.clienteId] = (newDeudores[pedido.clienteId] || 0) + (pedido.monto - (pedido.montoAbono || 0));
          }

          return {
            ...b,
            pedidos: [...b.pedidos, pedido],
            deudores: newDeudores,
          };
        }
        return b;
      }),
    }));
  },

  updatePedidoEstado: (businessId: string, pedidoId: string, estado: string, montoAbono?: number) => {
    set((state) => ({
      businesses: state.businesses.map((b) => {
        if (b.id === businessId) {
          const pedidoIndex = b.pedidos.findIndex((p) => p.id === pedidoId);
          if (pedidoIndex >= 0) {
            const pedido = b.pedidos[pedidoIndex];
            const newDeudores = { ...b.deudores };

            // Revertir deuda anterior
            if (pedido.estado === 'prestado') {
              newDeudores[pedido.clienteId] -= pedido.monto;
            } else if (pedido.estado === 'abono_parcial') {
              newDeudores[pedido.clienteId] -= (pedido.monto - (pedido.montoAbono || 0));
            }

            // Aplicar nuevo estado
            if (estado === 'prestado') {
              newDeudores[pedido.clienteId] = (newDeudores[pedido.clienteId] || 0) + pedido.monto;
            } else if (estado === 'abono_parcial') {
              newDeudores[pedido.clienteId] = (newDeudores[pedido.clienteId] || 0) + (pedido.monto - (montoAbono || 0));
            }

            const newPedidos = [...b.pedidos];
            newPedidos[pedidoIndex] = {
              ...pedido,
              estado: estado as 'pagado' | 'prestado' | 'abono_parcial',
              montoAbono,
            };

            return {
              ...b,
              pedidos: newPedidos,
              deudores: newDeudores,
            };
          }
        }
        return b;
      }),
    }));
  },

  addCliente: (businessId: string, cliente: Cliente) => {
    set((state) => ({
      businesses: state.businesses.map((b) => {
        if (b.id === businessId) {
          return {
            ...b,
            clientes: [...b.clientes, cliente],
          };
        }
        return b;
      }),
    }));
  },

  setMasterClients: (clients: any[]) => {
    set({ masterClients: clients });
  },

  loadFromExcel: (businessId: string, data: any) => {
    set((state) => ({
      businesses: state.businesses.map((b) => {
        if (b.id === businessId) {
          return {
            ...b,
            ...data,
          };
        }
        return b;
      }),
    }));
  },
}));
