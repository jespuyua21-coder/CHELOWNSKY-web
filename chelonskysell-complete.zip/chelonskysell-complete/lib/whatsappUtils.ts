import { Pedido } from './stores/businessStore';

/**
 * Genera un enlace de WhatsApp con un mensaje formateado
 */
export function generateWhatsAppLink(pedido: Pedido, groupMessage: boolean = false): string {
  const mensajePartes: string[] = [];

  mensajePartes.push(`📦 *PEDIDO #${pedido.numero}*`);
  mensajePartes.push('');
  mensajePartes.push(`👤 *Cliente:* ${pedido.clienteNombre}`);
  mensajePartes.push(`📱 *Teléfono:* ${pedido.clienteTelefono}`);
  
  if (pedido.ubicacion) {
    mensajePartes.push(`📍 *Ubicación:* ${pedido.ubicacion.direccion}`);
    mensajePartes.push(`🗺️ Mapa: ${pedido.ubicacion.linkMaps}`);
  }

  mensajePartes.push('');
  mensajePartes.push(`📝 *Descripción:* ${pedido.descripcion}`);
  mensajePartes.push(`💰 *Monto:* $${pedido.monto.toFixed(2)}`);

  if (pedido.estado === 'abono_parcial' && pedido.montoAbono) {
    const restante = pedido.monto - pedido.montoAbono;
    mensajePartes.push(`✅ *Abono:* $${pedido.montoAbono.toFixed(2)}`);
    mensajePartes.push(`⏳ *Restante:* $${restante.toFixed(2)}`);
  } else if (pedido.estado === 'prestado') {
    mensajePartes.push(`🔴 *Estado:* PRESTADO (No pagado)`);
  } else if (pedido.estado === 'pagado') {
    mensajePartes.push(`✅ *Estado:* PAGADO`);
  }

  if (pedido.notas) {
    mensajePartes.push('');
    mensajePartes.push(`📌 *Notas:* ${pedido.notas}`);
  }

  const mensaje = mensajePartes.join('%0a');
  const baseUrl = groupMessage ? 'https://wa.me/?text=' : 'https://wa.me/';

  if (groupMessage) {
    return `${baseUrl}${encodeURIComponent(mensaje)}`;
  } else {
    // Extraer solo números del teléfono
    const telefonoLimpio = pedido.clienteTelefono.replace(/\D/g, '');
    return `${baseUrl}${telefonoLimpio}?text=${encodeURIComponent(mensaje)}`;
  }
}

/**
 * Genera un mensaje formateado para mostrar en la app
 */
export function formatPedidoMessage(pedido: Pedido): string {
  return `
📦 Pedido #${pedido.numero}
👤 ${pedido.clienteNombre}
💰 $${pedido.monto.toFixed(2)}
Estado: ${getEstadoLabel(pedido.estado)}
${pedido.ubicacion ? `📍 ${pedido.ubicacion.direccion}` : ''}
  `.trim();
}

/**
 * Obtiene la etiqueta legible del estado del pedido
 */
export function getEstadoLabel(estado: string): string {
  const labels: { [key: string]: string } = {
    pagado: '✅ Pagado',
    prestado: '🔴 Prestado',
    abono_parcial: '⏳ Abono Parcial',
  };
  return labels[estado] || estado;
}

/**
 * Formato de moneda para México
 */
export function formatMoney(amount: number): string {
  return new Intl.NumberFormat('es-MX', {
    style: 'currency',
    currency: 'MXN',
  }).format(amount);
}

/**
 * Formato de fecha
 */
export function formatDate(date: string | Date): string {
  const d = typeof date === 'string' ? new Date(date) : date;
  return d.toLocaleDateString('es-MX', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
}

/**
 * Formato de fecha y hora
 */
export function formatDateTime(date: string | Date): string {
  const d = typeof date === 'string' ? new Date(date) : date;
  return d.toLocaleString('es-MX', {
    year: 'numeric',
    month: 'numeric',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

/**
 * Genera un mensaje recordatorio para WhatsApp
 */
export function generateReminderMessage(nombreCliente: string, monto: number, dias: number): string {
  const partes = [
    `Hola ${nombreCliente},`,
    ``,
    `Te recordamos que tienes un pago pendiente de $${monto.toFixed(2)}.`,
    ``,
    `El pago vence en ${dias} día(s).`,
    ``,
    `Por favor realiza el pago a la brevedad.`,
    ``,
    `¡Gracias!`,
  ];
  return partes.join('\n');
}
