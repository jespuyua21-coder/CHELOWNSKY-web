# Changelog

Todos los cambios notables a este proyecto serán documentados en este archivo.

El formato está basado en [Keep a Changelog](https://keepachangelog.com/),
y este proyecto adhiere a [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2024-01-16

### 🎉 Inicial Release

#### Agregado
- Dashboard para Business Owner con deudores y mejores clientes
- Módulo de creación de pedidos ultra rápido (< 30 segundos)
- Geolocalización automática con GPS
- Integración WhatsApp para enviar pedidos
- Panel SuperAdmin para gestionar clientes
- Excel como backend de datos (sin servidor)
- PWA - instalable en celular
- Autenticación con contraseña SuperAdmin
- Gestión de estados de pago (Pagado / Prestado / Abono)
- Descarga de Excel actualizado
- Generación automática de plantillas Excel
- Tema oscuro con branding Chelonsky (neon green)
- 100% responsive (mobile/tablet/desktop)
- 100% en español
- Documentación completa (4 guías + README)
- GitHub Actions CI/CD
- TypeScript tipado
- React 18 + Next.js 14

#### Características Técnicas
- Next.js 14 con App Router
- React 18 con Hooks
- TypeScript para type safety
- Tailwind CSS para estilos
- Zustand para estado global
- SheetJS para manejo de Excel
- PWA con next-pwa
- Geolocalización nativa
- WhatsApp Web API

#### Documentación
- README.md completo
- INSTALACION.md (paso a paso)
- GUIA_USUARIO.md (para usuarios finales)
- COMIENZA_AQUI.md (orientación)
- CONTRIBUTING.md (para desarrolladores)
- CHANGELOG.md (este archivo)

---

## [Futuro] - Roadmap

### Planeado para v1.1.0
- [ ] Editor de tickets personalizado
- [ ] Gráficos de ventas
- [ ] Notificaciones push
- [ ] Múltiples usuarios por negocio

### Planeado para v1.2.0
- [ ] Sincronización con Google Sheets
- [ ] Backup automático a Drive
- [ ] Facturación automática
- [ ] Integración PayPal/Stripe

### Planeado para v2.0.0
- [ ] Backend con Supabase (opcional)
- [ ] App nativa iOS/Android
- [ ] Marketplace de extensiones
- [ ] API pública
- [ ] White-label completo

---

## Versionado

Este proyecto usa [Semantic Versioning](https://semver.org/):

- `MAJOR` - Cambios incompatibles
- `MINOR` - Nuevas características compatibles
- `PATCH` - Bug fixes compatibles

## Cómo Contribuir

Ver [CONTRIBUTING.md](CONTRIBUTING.md) para instrucciones.

## Licencia

Este proyecto está bajo licencia MIT. Ver [LICENSE](LICENSE) para detalles.

## Contacto

- **Autor**: Chelonsky Store
- **GitHub**: [@chelonsky](https://github.com/chelonsky)
- **Email**: contacto@chelonsky.com
