'use client';

import { useState } from 'react';
import { useAuthStore } from '@/lib/stores/authStore';
import { LogOut, Menu, X } from 'lucide-react';

export function Header() {
  const { isAuthenticated, isSuperAdmin, businessName, logout } = useAuthStore();
  const [menuOpen, setMenuOpen] = useState(false);

  if (!isAuthenticated) {
    return null;
  }

  return (
    <header className="bg-dark-card border-b border-dark-border sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex-1">
            <h1 className="text-2xl font-bold text-chelonsky-400">
              {isSuperAdmin ? '🔐 SUPERADMIN' : '🏪 ' + businessName}
            </h1>
            <p className="text-sm text-gray-400">
              {isSuperAdmin ? 'Panel de administración CHELONSKYSELL' : 'Gestor de ventas y créditos'}
            </p>
          </div>

          <button
            onClick={logout}
            className="hidden sm:flex items-center gap-2 px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-all"
          >
            <LogOut className="w-4 h-4" />
            Salir
          </button>

          <button
            onClick={() => setMenuOpen(!menuOpen)}
            className="sm:hidden p-2 hover:bg-dark-border rounded-lg"
          >
            {menuOpen ? (
              <X className="w-6 h-6 text-chelonsky-400" />
            ) : (
              <Menu className="w-6 h-6 text-chelonsky-400" />
            )}
          </button>
        </div>

        {menuOpen && (
          <div className="mt-4 pt-4 border-t border-dark-border sm:hidden">
            <button
              onClick={() => {
                logout();
                setMenuOpen(false);
              }}
              className="w-full flex items-center gap-2 px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-all"
            >
              <LogOut className="w-4 h-4" />
              Salir
            </button>
          </div>
        )}
      </div>
    </header>
  );
}
